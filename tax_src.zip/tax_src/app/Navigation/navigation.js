/* jshint browser: true */
define(["knockout", "jquery", "util"], function (ko, $, util) {
    var Navigation = function (initmodule, param) {
        String.prototype.capitalize = function () {
            return this.toLowerCase().replace(/\b\w/g, function (m) {
                return m.toUpperCase();
            });
        };

        var self = this;
        
        self.loadModule = function(moduleName) {
            var modulePath = moduleName + "Module",
                moduleCall;
            $.displayErrorMessage = false;            
            require.undef(modulePath);
            var func = function(ctv) {
            	return function(){
                if (ctv) {
                    isCTVRequired = false;
                }
                requirejs([modulePath], function(module) {
                    moduleCall = new module(param);
                }, function(err) {
                    if (err.requireType === 'scripterror') {
                        window.location.pathname = '/auth/';
                        return;
                    }
                });
            	};
            };
            if (util.authentify[moduleName] !== undefined) {
                //proceed with authentication through CTV/TTV
                var urlParams = util.authentify[moduleName];
                var endPointURL = new SVB.ooba.endPointURL(urlParams.urlId, urlParams.urlName, false, null);
                var authenticate = true;
               // ajax.updateAuthentify(function(data){
               // 	isCTVRequired = data.isCTVRequired;
                	SVB.ooba.CTVAuthentication(endPointURL, func(authenticate));
              //  });

            } else {
                //direct load
                func()();
            }

        };


        if (!initmodule) {
            initmodule = "overviewCa";
        }

        require.undef(initmodule);
        self.loadModule(initmodule);

        self.navigatePointer = function (moduleName) {
            var secNavi = $("[data-svb-class='header-section-navigation-list']>li a").removeClass("svb-header-section-navigation-overflow-active-page svb-active");

            if (secNavi.length > 0) {
                $($("a[data-svb-cc-module='" + moduleName + "']")[0]).addClass("svb-header-section-navigation-overflow-active-page svb-active");
            } else {
                $('li[data-svb-class="header-primary-navigation-menu"]>a').removeClass("svb-active");
                var modSearch = moduleName.substring(1, 5);
                $('li[data-svb-class="header-primary-navigation-menu"]>a:contains("' + modSearch + '")').addClass("svb-active");
            }
        };

        self.pageNavi = function (m, e) {
            //if (!self.BankUser()) {
            if ($(e.target).hasClass('unselectable')) {
                return false;
            }

            var moduleJS = $(e.target).data('svb-cc-module');

            $("[data-svb-class='header-section-navigation-list']>li a").removeClass("svb-header-section-navigation-overflow-active-page svb-active");
            $(e.target).addClass("svb-header-section-navigation-overflow-active-page svb-active");

            require.undef("mockConfig");
            require.undef(moduleJS);
            self.loadModule(moduleJS);
            //}
        };

        var navcontainer = $("[data-svb-class='header-section-navigation-list']")[0];

        if (navcontainer) {
            ko.cleanNode(navcontainer);
            ko.applyBindings(self, navcontainer);
        }

        if (initmodule) {
            if (initmodule !== "payments" && initmodule !== "modalwindowdispute" && initmodule !== "newcard"  && initmodule !== "cardstatusoverlay" && initmodule !== "pendingpaymentapproval" && initmodule !== "setupautopayments" && initmodule !== "statementsdownloads" && initmodule !== "addpayments" && initmodule !== "pendingapproval" && initmodule !== "verifypayments" && initmodule !== "confirmpayments" && initmodule !== "modalwindow" && initmodule !== "dispute" && initmodule !== "searchforbank" && initmodule !== "permanentincrease") {
                self.navigatePointer(initmodule);
            } else {
                var pointerModule = $('.svb-header-section-navigation-list').find('.svb-active').attr('data-svb-cc-module');
                self.navigatePointer(pointerModule);
            }
        }
    };
    return Navigation;

});