/* jshint browser: true */
define(["knockout", "jquery", "html!incomeTaxTpl", "ajaxCall", "util", "widgetRegistry", "css!caStyles"], function (ko, $, incomeTaxTpl, AJAX, util) {
    var IncomeTax = function () {
        var self = this;


        self.element = $('.dvImage')[0];
        self.element.innerHTML = incomeTaxTpl;

        $('.dvImage').hide();
        
        // return self;
    };

    return IncomeTax;
});