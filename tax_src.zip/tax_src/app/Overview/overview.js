/* jshint browser: true */
define(["knockout", "jquery", "html!overviewTpl", "ajaxCall", "util", "widgetRegistry", "css!caStyles"], function (ko, $, overviewtpl, AJAX, util) {
    var Overview = function () {
        var self = this;


        self.element = $('.svb-cardsAdmin')[0];
        self.element.innerHTML = overviewtpl;

        $('.svb-cardsAdmin').hide();

        self.verbiage = util.verbiage;
        self.urls = util.urls;

        util.selectedEncAccNo = "";

        self.totalAccount = 0;
        self.programData = {};

        self.accountLabel = ko.observable();
        self.resetDropdown = ko.observable();

        self.serverFail = ko.observable(false);
        self.programInfoFail = ko.observable(false);

        self.serverErrorMessage = ko.observable(self.verbiage.serverErrorMessage);
        self.contactServiceMsg = ko.observable(self.verbiage.contactServiceInstructionLabel + "<a href='" + self.urls.contactServiceUrl + "' target='_blank'>" + self.verbiage.clientSupportLabel + "</a>.");

        //Boolean to show and hide tray container
        self.showTray = ko.observable(false);

        self.checkDeliquentWarning = true;
        self.warningMessageScenarios = {};
        self.warningMessageScenarios.deliquentWarning = false;
        self.warningMessageScenarios.paymentApprovalWarning = false;
        self.warningMessageScenarios.limitChangeWarning = false;
        self.warningMessageScenarios.cardApprovalWarning = false;

        self.cardHolderChosen = {};
        self.companyLimit = ko.observable();
        self.currentBalance = ko.observable();
        self.availableCredit = ko.observable();
        self.controlCard = ko.observable();
        self.pending = ko.observable();
        self.notificationCount = ko.observable("0");
        self.notificationTooltip = ko.observable();

        self.showNotification = ko.observable(false);
        self.notificationIcon = ko.observable(false);
        self.showPendingMaintenance = false;
        self.autoPay = ko.observable('Enabled');
        self.selectedProgram = ko.observable();
        self.count = ko.observable();
        self.selectedAction = ko.observable();
        self.controlCompanyName = ko.observable();
        self.controlAccount = ko.observable();
        self.controlCompanyId = ko.observable();
        self.controlBillingType = ko.observable();
        self.controlLastStmtDate = ko.observable();
        self.controlLastStmtBalance = ko.observable();
        self.controlLastPaymtDate = ko.observable();
        self.controlLastPaymtAmt = ko.observable();
        self.controlMinPaymtDate = ko.observable();
        self.controlMinPaymtDue = ko.observable();
        self.controlAutopay = ko.observable();
        self.programDefault = ko.observable();
        self.totalSubAccountsFetched = ko.observable();
        self.warningMessage = ko.observable(false);
        self.noWarningMessage = ko.observable(true);
        self.selectedCard = ko.observable();
        self.loaderStatus = ko.observable();
        self.loaderModule = ko.observable("ca-overview");
        self.loaderDetail = ko.pureComputed(function () {
            var detail = {};
            detail.status = self.loaderStatus();
            detail.module = self.loaderModule();
            return detail;
        });
        self.callExist = ko.observable(false);
        self.callExist.subscribe(function (item) {
            if (!item) {
                self.loaderStatus(false);
                self.loaderModule("ca-overview");
            }
        });
        self.manageSpendRequest = {};
        util.pageLoader = self.loaderStatus;
        self.isBankUser = ko.observable();

        self.entitlementObject = ko.observable({
            managePayment: false
        });
        self.donutDetails = ko.observable();
        self.actionsRender = ko.observable();
        self.entitledPrograms = ko.observable();
        self.warningMessageText = ko.observable("");
        self.takeActionText = ko.observable("");
        self.paymentsApprovalCount = ko.observable("");
        self.tabledata = ko.observableArray();
        self.programsOptions = ko.observableArray();
        self.actions = ko.observableArray([]);
        self.cardSelected = ko.observableArray([]);

        self.enableManageSpend = ko.observable(true);
        self.enablePayments = ko.observable(true);
        self.enableCardStatus = ko.observable(true);
        self.enableLostStolen = ko.observable(true);
        self.auditObj = {};
        self.auditObj.auditActivity = "overview";
        self.auditResponse = function () {

        };

        self.accountText = ko.pureComputed(function () {
            return self.programsOptions().length > 1 ? "Accounts" : "Account";
        });

        self.notificationCount.subscribe(function (newValue) {
            var verbiageText = (newValue === 1) ? self.verbiage.maintenanceRequest : self.verbiage.maintenanceRequests;
            self.notificationTooltip(self.verbiage.youHave + newValue + verbiageText);
        });

        self.selectedAction.subscribe(function (actionItem) {
            var params = {};
            if (actionItem.value === "Statements/Downloads") {
                self.loaderModule("ca-statements-downloads");

                params = {};
                params.initModule = "ca-overview";

                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("statementsdownloads", params);
                });
            } else if (actionItem.id === '1') {
                params = {};
                params.initModule = "ca-overview";
                params.newCards = [];

                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("newcard", params);
                });
            } else if (actionItem.id === '2') {
                params = {
                    show: "approval",
                    from: "overview",
                    tabName: "pendingMaintenance",
                    showApproval: self.notificationIcon(),
                    showMaintenance: self.showPendingMaintenance
                };

                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("pendingapproval", params);
                });
            } else if (actionItem.id === '4') {
                if (!self.isBankUser()) {
                    params = {};

                    params.tab = "tab3";
                    params.initModule = "ca-overview";

                    self.actions([]);
                    self.actions(self.getActionsList(self.entitlementObject()));

                    require(["navigation", "mockConfig"], function (navigation) {
                        navigation("payments", params);
                    });
                }
            } else if (actionItem.id === '5') {
                window.open(self.urls.rewardUrl, '_blank');

                $('.ca-content').remove();
                require(["navigation", "mockConfig"], function (navigation) {
                    nav = navigation("overviewCa");
                });
            } else if (actionItem.id === '6') {
                window.open(self.urls.masterCardUrl, '_blank');

                $('.ca-content').remove();
                require(["navigation", "mockConfig"], function (navigation) {
                    nav = navigation("overviewCa");
                });
            } else if (actionItem.id === '7' || actionItem.id === '8') {
                window.open(self.urls.smartDataUrl, '_blank');

                $('.ca-content').remove();
                require(["navigation", "mockConfig"], function (navigation) {
                    nav = navigation("overviewCa");
                });
            }
        });

        self.programsList = function (programs) {
            var index = 0,
                programArray = [];
            for (index = 0; index < programs.length; index++) {
                programArray.push(programs[index].program);
            }
            return programArray;
        };

        self.paymentNotificationReq = function (programItem) {
            var programDetail = programItem.program,
                userEntitlement = programItem.program.userEntitlement,
                data = {},
                requestObject = {};

            for (var attrname in programDetail) {
                if (attrname === "prin" || attrname === "sys" || attrname === "agent" || attrname === "companyId") {
                    if (attrname === "companyId") {
                        self.companyId = programDetail[attrname];
                    }
                    requestObject[attrname] = programDetail[attrname];
                } else {
                    continue;
                }
            }

            data = {
                "data": {
                    "program": {
                        "companyId": requestObject.companyId,
                        "sys": requestObject.sys,
                        "prin": requestObject.prin,
                        "agent": requestObject.agent,
                        "userEntitlement": {
                            "paymentApproval": self.isBankUser() ? false : userEntitlement.paymentApproval,
                            "limitApproval": self.isBankUser() ? false : userEntitlement.limitApproval,
                            "newCardApproval": self.isBankUser() ? false : userEntitlement.newCardApproval
                        }
                    }
                }
            };

            return data;
        };

        self.companyViewReq = function (programsArray, count) {
            var programsListObject = [],
                dataObject = {},
                data = {},
                programObject,
                reqObj = {},
                attrname = "";
            if (count >= 0) {
                var begin = count + 1,
                    //end = count + 50,
                    end = count + parseInt(util.companyAccountSeqLimit, 10),
                    misc = {
                        beginSeq: begin,
                        endSeq: end
                    },
                    progDetail = programsArray.program;
                if (progDetail.hasOwnProperty('misc')) {
                    progDetail.misc = {};
                    progDetail.misc = misc;
                } else {
                    progDetail.misc = misc;
                }
                dataObject.program = {};
                reqObj = dataObject.program;
                for (attrname in progDetail) {
                    if (attrname === "prin" || attrname === "sys" || attrname === "agent" || attrname === "companyId" || attrname === "misc") {
                        if (attrname === "companyId") {
                            self.companyId = progDetail[attrname];
                        }
                        reqObj[attrname] = progDetail[attrname];
                    } else {
                        continue;
                    }
                }
            } else {
                for (var index = 0; index < programsArray.length; index++) {
                    programObject = {};
                    var progObj = programsArray[index];
                    for (attrname in progObj) {
                        if (attrname === "prin" || attrname === "sys" || attrname === "agent" || attrname === "companyId" || attrname === "misc" || attrname === "billingType") {
                            programObject[attrname] = progObj[attrname];
                        } else {
                            /*if (attrname === "billingType") {
                             self.billingType = progObj[attrname];

                             }*/
                            continue;
                        }
                    }
                    programsListObject.push({
                        program: programObject
                    });
                }
                dataObject.programs = programsListObject;
            }
            data.data = dataObject;
            return data;
        };

        self.getCompanyViewRes = function (data) {
            var programDetails = [],
                index,
                newIndex;
            if (data.data) {
                var responseStatus;
                if (data.data && data.data.programDetails) {
                    programDetails = data.data.programDetails;
                }
                for (index = 0; index < programDetails.length; index++) {
                    for (newIndex = 0; newIndex < util.entitledPrograms.length; newIndex++) {
                        if (programDetails[index].program.companyId.trim("") === util.entitledPrograms[newIndex].program.companyId) {
                            var utilObj = util.entitledPrograms[newIndex].program;
                            var resObj = programDetails[index].program;
                            for (var attrname in resObj) {
                                if (attrname === "comapnyID") {
                                    continue;
                                } else {
                                    if (resObj[attrname]) {
                                        utilObj[attrname] = resObj[attrname].trim();
                                    }
                                }
                            }
                            break;
                        }
                    }

                }


                self.programs = self.getProgramsList(util.entitledPrograms);
                self.programsOptions(self.programs);

                if (util.navigateTo.hasOwnProperty("companyId")) {
                    for (var n = 0; n < self.programs.length; n++) {
                        if (self.programs[n].id === util.navigateTo.companyId.trim()) {
                            self.programDefault(n);
                            break;
                        }
                    }
                } else {
                    self.programDefault(0);
                }

                if (data.data.result && data.data.result.messageCode) {
                    self.auditObj.programName = self.programs[self.programDefault()].value;
                    responseStatus = data.data.result.messageCode;
                    if (responseStatus !== "0") {
                        self.auditObj.processCode = "0";
                        AJAX.overviewAuditEvent(self.auditObj, self.auditResponse);
                    }
                }
            }

            ko.cleanNode($('.ca-overview')[0]);
            ko.applyBindings(self, $('.ca-overview')[0]);
            $('.svb-cardsAdmin').show();
            if ($('.svb-ca-loader-container').length) {
                $('.svb-ca-initial-loader').removeClass("overlay-active");
                $('#svb-ca-initial-indicator').removeClass("svb-processing-indicator");
                $('.svb-ca-loader-container').remove();
            }
        };

        self.entitledPrograms.subscribe(function (entitleObject) {
            self.fetchedPrograms = self.programsList(entitleObject);
            self.companyViewReqData = self.companyViewReq(self.fetchedPrograms);
            if (!util.selectedProgram) {
                self.loaderStatus(true);
                self.loaderModule("ca-overview");
                AJAX.getCompanyView(self.companyViewReqData, self.getCompanyViewRes);
            } else {
                self.loaderStatus(false);
                self.loaderModule("ca-overview");
                self.programs = self.getProgramsList(util.entitledPrograms);
                self.programsOptions(self.programs);
                for (var i = 0; i < self.programsOptions().length; i++) {
                    if (util.selectedProgram.id === self.programsOptions()[i].id) {
                        //self.cachedProgram = util.entitledPrograms[i];
                        self.programDefault(i);
                        // self.selectedProgram(util.selectedProgram);
                        self.companyId = util.selectedProgram.id;
                        break;
                    }
                }
                ko.cleanNode($('.ca-overview')[0]);
                ko.applyBindings(self, $('.ca-overview')[0]);
                $('.svb-cardsAdmin').show();
            }
        });

        self.doSort = function (collection, prop, asc) {
            collection.sort(function (a, b) {
                var A, B;
                if (prop === "cardHolderName") {
                    A = a.account[prop].toLowerCase().trim();
                    B = b.account[prop].toLowerCase().trim();
                } else {
                    A = a[prop].toLowerCase().trim();
                    B = b[prop].toLowerCase().trim();
                }
                if (asc) {
                    if (A > B) {
                        return 1;
                    } else if (A < B) {
                        return -1;
                    } else {
                        return 0;
                    }
                } else {
                    if (A > B) {
                        return -1;
                    } else if (A < B) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            });
            return collection;
        };


        self.getUserEntitlementsList = function () {};

        self.getActionsList = function (item) {
            var tempArray = [];

            tempArray = [{
                id: '0',
                value: self.verbiage.moreActionsLabel
            }];

            if (item.openCard) {
                tempArray.push({
                    id: '1',
                    value: self.verbiage.newCardLabel
                });
            }
            if (self.showPendingMaintenance) {
                tempArray.push({
                    id: '2',
                    value: self.verbiage.pendingMaintenanceRequestLabel
                });
            }
            tempArray.push({
                id: '3',
                value: self.verbiage.statementsOrDownloadsLabel
            });

            if (item.manageAcount && item.managePayment) {
                tempArray.push({
                    id: '4',
                    value: self.verbiage.managePaymentAccountsLabel
                });
            }
            
			if(self.programData.program.prin==="0010" ) {
                tempArray.push({
                    id: '5',
                    value: self.verbiage.rewardsLabel
                });

                tempArray.push({
                    id: '6',
                    value: self.verbiage.masterCardEasySavingsLabel
                });
            
                tempArray.push({
                    id: '7',
                    value: self.verbiage.smartDataLabel
                });
            } else if(self.programData.program.prin==="4000") {
                 tempArray.push({
                    id: '8',
                    value: self.verbiage.smartDataLabel
                 });
            }

            tempArray.push();

            return tempArray;
        };

        self.getProgramsList = function (programs) {
            var index = 0,
                programArray = [],
                sortedList;
            if (programs.length <= 1) {
                self.accountLabel(self.verbiage.accountLabel);
            } else {
                self.accountLabel(self.verbiage.accountsLabel);
            }
            for (index = 0; index < programs.length; index++) {
                var programObj = {};
                programObj.id = programs[index].program.companyId;
                programs[index].program.programName = programs[index].program.companyName + "-" + programs[index].program.progType + "-" + programs[index].program.companyId;
                programObj.value = programs[index].program.programName;
                programArray.push(programObj);
            }
            sortedList = self.doSort(programArray, "value", true);
            return sortedList;
        };

        self.generateDonut = function (data) {
            // var arr = [];
            self.currentBalance(data.currentBalance);

            self.availableCredit((data.availableCredit) ? data.availableCredit : "0");
            self.pending((data.pending) ? data.pending : "0");
            // self.companyLimit(data.creditLimit);
            /* arr.push(parseInt(data.currentBalance));
             arr.push(parseInt(data.availableCredit));
             arr.push(parseInt(data.pending));*/
            var donutObject = {
                "currentBalance": "",
                "pending": "",
                "availableCredit": ""
            };
            for (var attrname in data) {
                if (attrname === "currentBalance" || attrname === "availableCredit" || attrname === "pending") {
                    donutObject[attrname] = (data[attrname]) ? data[attrname] : "0";
                } else if (attrname === "creditLimit") {
                    self.companyLimit(data[attrname]);
                } else {
                    continue;
                }
            }
            //   self.doSort (donutObject, prop, false) {
            self.donutDetails(donutObject);
            // self.donutArray(arr);
        };


        self.getControlAccount = ko.computed(function () {
            if (self.controlCard()) {
                self.generateDonut(self.controlCard().account);
                AJAX.getControlCardDetail(self.controlAccountReq, self.controlAccountRes);
            }
        });

        self.copyArray = function (oldArray) {
            var newArray = [];
            for (var index = 0; index < oldArray.length; index++) {
                newArray.push(oldArray[index]);
            }
            return newArray;
        };

        self.getCompanyViewAccountRes = function (data) {
            if (data.data) {
                self.auditObj.programName = self.programData.program.programName;
                var responseStatus;
                if (data.data.result && data.data.result.messageCode) {
                    responseStatus = data.data.result.messageCode;
                    if (responseStatus !== "0") {
                        self.auditObj.processCode = "0";
                        AJAX.overviewAuditEvent(self.auditObj, self.auditResponse);
                        if (!self.programData.program.subAccount) {
                            self.programInfoFail(true);
                            self.loaderStatus(false);

                            $('[data-svb-cc-module="paymentactivity"]').addClass('svb-ca-inactive').addClass('unselectable');
                            $('[data-svb-cc-module="cardholder"]').addClass('svb-ca-inactive').addClass('unselectable');

                            return;
                        }
                    }
                }
                self.auditObj.processCode = "1";

                var accountDetailArray = data.data.accountDetails,
                    conAccountArr = [],
                    newData = {},
                    tableDataStructure = {};
                self.totalAccount = self.totalAccount + accountDetailArray.length;
                if (util.allProgramAccounts.length === 0) {
                    util.allProgramAccounts.push.apply(util.allProgramAccounts, accountDetailArray);
                }
                if (accountDetailArray.length === parseInt(util.companyAccountSeqLimit)) {
                    /*if (accountDetailArray.length === 50) {*/
                    self.nextHit = true;
                } else {
                    self.nextHit = false;
                }
                if (accountDetailArray[0].account.type === "C") {
                    if (!self.fetchedControlCard) {
                        // self.nextHit = true;
                        self.fetchedControlCard = true;
                        self.totalSubAccounts = self.totalAccount - 1;
                        self.programData.program.controlCard = accountDetailArray[0];
                        conAccountArr.push({
                            'accNumber': self.programData.program.controlCard.account.encAccntNumber
                        });
                        newData.account = conAccountArr;
                        self.controlAccountReq = {
                            data: newData
                        };
                        self.controlCard(self.programData.program.controlCard);
                        self.cardHolderChosen.controlCard = self.programData.program.controlCard;
                        util.controlCard = self.programData.program.controlCard;
                        accountDetailArray.splice(0, 1);
                        self.programData.program.subAccount = accountDetailArray;
                        self.doSort(self.programData.program.subAccount, "cardHolderName", true);
                        self.cardHolderChosen.subAccounts = self.programData.program.subAccount;
                        util.subAccounts = self.programData.program.subAccount;
                        tableDataStructure = {
                            prin: self.programData.program.prin,
                            sys: self.programData.program.sys,
                            agent: self.programData.program.agent,
                            program: self.programData.program,
                            subAccount: self.programData.program.subAccount
                        };
                        self.tabledata(tableDataStructure);
                        self.totalSubAccounts = 1;
                    } else {
                        self.nextHit = false;
                    }
                } else if (accountDetailArray[0].account.type !== "C") {
                    self.totalSubAccounts = self.totalSubAccounts + 1;
                    self.programData.program.subAccount.push.apply(self.programData.program.subAccount, accountDetailArray);
                    util.allProgramAccounts.push.apply(util.allProgramAccounts, accountDetailArray);
                }
                if (self.nextHit) {
                    self.companyViewAccountReqData = self.companyViewReq(self.programData, self.totalAccount);
                    self.callExist(true);
                    AJAX.getTableData(self.companyViewAccountReqData, self.getCompanyViewAccountRes);
                } else {
                    self.doSort(self.programData.program.subAccount, "cardHolderName", true);
                    //self.totalSubAccountsFetched(self.totalSubAccounts);
                    tableDataStructure = {
                        prin: self.programData.program.prin,
                        sys: self.programData.program.sys,
                        agent: self.programData.program.agent,
                        program: self.programData.program,
                        subAccount: self.programData.program.subAccount
                    };
                    if (self.callExist()) {
                        self.callExist(false);
                    }
                    self.tabledata(tableDataStructure);
                }
                //}
                // }
            }
        };

        self.getWarningDetails = function (program) {
            var index = 0;

            self.noWarningMessage(true);
            self.warningMessage(false);

            self.showNotification(false);

            for (index = 0; index < util.showWarningMessages.length; index += 1) {
                if (util.showWarningMessages[index].program === program.companyId) {
                    self.warningMessageScenarios.deliquentWarning = util.showWarningMessages[index].displayDeliquentWarningMessage;
                    self.warningMessageScenarios.paymentApprovalWarning = util.showWarningMessages[index].displayPaymentApprovalWarningMessage;

                    if ((self.warningMessageScenarios.deliquentWarning || self.warningMessageScenarios.paymentApprovalWarning) && util.showWarningMessages[index].warningMessageText !== undefined) {
                        self.warningMessageText(util.showWarningMessages[index].warningMessageText);
                        self.takeActionText(util.showWarningMessages[index].takeActionText);
                    }

                    self.notificationCount(util.showWarningMessages[index].notificationsCount);
                    self.paymentsApprovalCount(util.showWarningMessages[index].paymentsApprovalCount);

                    util.reminderObject = util.showWarningMessages[index].reminderObject;
                }
            }

            if (self.notificationIcon() && self.notificationCount() > 0) {
                self.showNotification(true);
            }

            if (!self.isBankUser()) {
                if (self.warningMessageScenarios.paymentApprovalWarning && util.showWarningAlert(program.companyId)) {
                    self.noWarningMessage(false);
                    self.warningMessage(true);
                } else if (self.warningMessageScenarios.deliquentWarning && util.showWarningAlert(program.companyId)) {
                    self.noWarningMessage(false);
                    self.warningMessage(true);
                } else {
                    self.noWarningMessage(true);
                    self.warningMessage(false);
                }
            }
        };

        self.displayControlCardDetails = function (data) {
            if (!self.cachedProgram) {
                self.controlCompanyName(self.programData.program.companyName);
                self.controlBillingType(self.programData.program.billingType);
            } else {
                self.controlCompanyName(self.cachedProgram.program.companyName);
                self.controlBillingType(self.cachedProgram.program.billingType);
            }

            var contAccount = "...." + data.lastFourDigit;
            self.controlAccount(contAccount);
            self.controlCompanyId(self.companyId);

            self.controlLastStmtDate(data.lastStmtDate);
            self.controlLastStmtBalance(data.lastStmtBalance);
            self.controlLastPaymtDate(data.lastPaymentDate);
            self.controlLastPaymtAmt(data.lastPaymentAmt);
            self.controlMinPaymtDate(data.minPayDate);
            self.controlMinPaymtDue(data.minPayDue);
            self.controlAutopay(data.autopay);

            if (self.cachedProgram === undefined) {
                if (data.autopay.toUpperCase() === 'DISABLED') {
                    if (!util.isBankUser && util.controlCardProgram.userEntitlement.createEditPayment.toUpperCase() === "TRUE") {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                } else if (data.autopay.toUpperCase() === 'ENABLED') {
                    if (!util.isBankUser && util.controlCardProgram.userEntitlement.viewPayment.toUpperCase() === "TRUE") {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                } else if (data.autopay.toUpperCase() === 'PENDING APPROVAL') {
                    if (!util.isBankUser && util.controlCardProgram.userEntitlement.viewPayment.toUpperCase() === "TRUE" && util.controlCardProgram.userEntitlement.paymentApproval.toUpperCase() === "TRUE" && data.autopaymentDetails.initiatorFlag && data.autopaymentDetails.initiatorFlag.toUpperCase() === 'FALSE') {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                }
            } else {
                if (data.autopay.toUpperCase() === 'DISABLED') {
                    if (!util.isBankUser && self.cachedProgram.program.userEntitlement.createEditPayment.toUpperCase() === "TRUE") {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                } else if (data.autopay.toUpperCase() === 'ENABLED') {
                    if (!util.isBankUser && self.cachedProgram.program.userEntitlement.viewPayment.toUpperCase() === "TRUE") {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                } else if (data.autopay.toUpperCase() === 'PENDING APPROVAL') {
                    if (!util.isBankUser && self.cachedProgram.program.userEntitlement.viewPayment.toUpperCase() === "TRUE" && self.cachedProgram.program.userEntitlement.paymentApproval.toUpperCase() === "TRUE" && data.autopaymentDetails.initiatorFlag && data.autopaymentDetails.initiatorFlag.toUpperCase() === 'FALSE') {
                        $("#autopay").addClass("highlight");
                        $("#autopay").removeClass("greyout");
                    } else {
                        $("#autopay").removeClass("highlight");
                        $("#autopay").addClass("greyout");
                    }
                }
            }
        };

        self.getCachedAccountView = function (data) {
            self.getWarningDetails(data);

            var tableDataStructure = {
                prin: data.prin,
                sys: data.sys,
                agent: data.agent,
                program: self.programData.program,
                subAccount: data.subAccount
            };

            self.tabledata(tableDataStructure);
            self.displayControlCardDetails(data.controlCard.account);
        };
        /*
         * Depends on DropDown Click for Navigation to Approval
         * Depens on Bell Icon to load Approval.
         * */
        self.controlAccountRes = function (data) {
            if (data.data) {
                self.auditObj.programName = self.programData.program.programName;
                var responseStatus;
                if (data.data.accountDetails[0].result && data.data.accountDetails[0].result.messageCode) {
                    responseStatus = data.data.accountDetails[0].result.messageCode;
                    if (responseStatus !== "0") {
                        self.programInfoFail(true);
                        self.loaderStatus(false);

                        $('[data-svb-cc-module="paymentactivity"]').addClass('svb-ca-inactive').addClass('unselectable');
                        $('[data-svb-cc-module="cardholder"]').addClass('svb-ca-inactive').addClass('unselectable');

                        self.auditObj.processCode = "0";
                        AJAX.overviewAuditEvent(self.auditObj, self.auditResponse);
                        return;
                    }
                }
                self.auditObj.processCode = "1";
                AJAX.overviewAuditEvent(self.auditObj, self.auditResponse);

                var controlCard = data.data.accountDetails[0].account,
                    utilObj,
                    warningObject = {},
                    displayWarningObject = {};

                if (util.showWarningMessages === undefined) {
                    util.showWarningMessages = [];
                    util.displayWarningMessages = [];
                }

                warningObject.program = self.programData.program.companyId;
                displayWarningObject.program = self.programData.program.companyId;

                if (util.reminderObject !== undefined) {
                    util.reminderObject.programName = self.programData.program.companyName;
                    util.reminderObject.progType = self.programData.program.progType;
                }

                utilObj = self.programData.program.controlCard.account;
                for (var attrname in controlCard) {
                    if (attrname !== "lastFourDigit" || attrname !== "type") {
                        utilObj[attrname] = controlCard[attrname];
                    }
                }
                if (!self.isBankUser() && self.programData.program.userEntitlement.createEditPayment.toUpperCase() === 'TRUE' && utilObj.paymentPastDue.toUpperCase() === "TRUE") {
                    if (self.checkDeliquentWarning) {
                        warningObject.displayDeliquentWarningMessage = true;
                        warningObject.displayPaymentApprovalWarningMessage = false;
                        self.warningMessageScenarios.deliquentWarning = true;
                        self.warningMessageScenarios.paymentApprovalWarning = false;
                        self.warningMessageText(self.verbiage.deliquentWarningMessage);
                        self.takeActionText(self.verbiage.makePaymentLabel);
                    } else {
                        warningObject.displayDeliquentWarningMessage = false;
                        warningObject.displayPaymentApprovalWarningMessage = self.warningMessageScenarios.paymentApprovalWarning ? true : false;

                        self.warningMessageScenarios.paymentApprovalWarning = self.warningMessageScenarios.paymentApprovalWarning ? true : false;
                    }

                    warningObject.warningMessageText = self.warningMessageText();
                    warningObject.takeActionText = self.takeActionText();
                } else {
                    warningObject.displayDeliquentWarningMessage = false;
                    warningObject.displayPaymentApprovalWarningMessage = self.warningMessageScenarios.paymentApprovalWarning ? true : false;
                }

                warningObject.notificationsCount = self.notificationCount();
                warningObject.paymentsApprovalCount = self.paymentsApprovalCount();

                warningObject.reminderObject = util.reminderObject;

                displayWarningObject.showWarningMessage = true;

                util.showWarningMessages.push(warningObject);
                util.displayWarningMessages.push(displayWarningObject);

                self.getWarningDetails(self.programData.program);

                if (!self.callExist()) {
                    self.loaderStatus(false);
                    self.loaderModule("ca-overview");
                }

                self.displayControlCardDetails(utilObj);
                //Invocation point to load pending Maintenance Screen
                if (util.navigateTo) {
                    if (util.navigateTo.moduleName === "PENDING_MAINTENANCE") {
                        /*var params = {
                         show: "approval",
                         from: "overview",
                         tabName: "pendingMaintenance",
                         showApproval: self.notificationIcon(),
                         showMaintenance: self.showPendingMaintenance()
                         };

                         require(["navigation", "mockConfig"], function (navigation) {
                         var nav = navigation("pendingapproval", params);
                         });
                         */
                        delete util.navigatTo;
                        self.openPendingApproval();
                    } else if (util.navigateTo.moduleName === "PENDING_APPROVAL") {
                        delete util.navigatTo;
                        self.openPendingApproval();
                    } else if (util.navigateTo.moduleName === "CARDHOLDER_ACTIVITY") {
                        delete util.navigatTo;
                        require(["navigation", "mockConfig"], function (navigation) {
                            navigation("cardholder", self.cardHolderChosen);
                        });
                    } else if (util.navigateTo.moduleName === "PAYMENT_ACTIVITY") {
                        delete util.navigatTo;
                        require(["navigation", "mockConfig"], function (navigation) {
                            navigation("paymentactivity");
                        });
                    }
                    // delete util.navigateTo;
                }
                // }
                //}
            }
        };

        self.entitlements = ko.pureComputed(function () {
            if (self.entitlementObject()) {
                return;
            }
        });

        self.programActions = ko.pureComputed(function () {
            if (self.actionsRender()) {
                return;
            }
        });

        self.resetValues = function () {
            var $target;
            var $tray;
            $target = $('.ca-content-table');
            $tray = $target.next();
            self.resetDropdown({
                id: '1',
                value: self.verbiage.activeLabel,
                hideOption: ko.observable()
            });
            $target.find('.input-box').val("");
            $target.find('.erase').addClass('search-icon').removeClass('erase');
            $tray.find('.slider-container').css('opacity', 0);
            $tray.next().find('.slider-button-container').css('opacity', 0);
            $('[filterdropdown = "id"]').find('.wrapper-dropdown').removeClass('active');
            self.showTray(false);
        };

        self.notificationRes = function (data) {
            if (data.data) {
                var paymentsApproval = (data.data.count.payment !== undefined) ? data.data.count.payment : "0",
                    paymentWorkflowIds = (data.data.paymentWorkflowIds !== undefined) ? data.data.paymentWorkflowIds : [];

                self.warningMessageScenarios.paymentApprovalWarning = false;
                self.warningMessageScenarios.deliquentWarning = false;

                self.paymentsApprovalCount(parseInt(paymentsApproval));

                self.checkDeliquentWarning = true;

                self.notificationCount(data.data.count.overAllCount);

                if (paymentsApproval !== "0") {
                    self.checkDeliquentWarning = false;

                    self.warningMessageScenarios.paymentApprovalWarning = true;

                    if (data.data.paymentTakeAction.toUpperCase() === "VIEW") {
                        if (util.controlCardProgram.userEntitlement.viewPayment.toUpperCase() !== "TRUE") {
                            self.warningMessageScenarios.paymentApprovalWarning = false;
                        }

                        self.warningMessageText(self.verbiage.viewPaymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.viewPaymentLabel);
                    } else if (data.data.paymentTakeAction.toUpperCase() === "APPROVE") {
                        if (util.controlCardProgram.userEntitlement.viewPayment.toUpperCase() !== "TRUE" && util.controlCardProgram.userEntitlement.paymentApproval.toUpperCase() !== "TRUE") {
                            self.warningMessageScenarios.paymentApprovalWarning = false;
                        }

                        self.warningMessageText(self.verbiage.paymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.approvePaymentLabel);
                    } else {
                        self.warningMessageText(self.verbiage.remindPaymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.sendReminderLabel);

                        util.reminderObject = {
                            paymentWorkflowIds: paymentWorkflowIds
                        };
                    }

                }
            }
        };

        self.refreshNotificationRes = function (data) {
            if (data.data) {

                self.loaderStatus(false);
                self.loaderModule("ca-overview");

                self.warningMessageScenarios.paymentApprovalWarning = false;
                self.warningMessageScenarios.deliquentWarning = false;

                var paymentsApproval = (data.data.count.payment !== undefined) ? data.data.count.payment : "0",
                    index = 0;

                self.paymentsApprovalCount(parseInt(paymentsApproval));

                self.checkDeliquentWarning = true;

                self.notificationCount(data.data.count.overAllCount);

                if (paymentsApproval !== "0") {
                    self.checkDeliquentWarning = false;
                    self.warningMessageScenarios.paymentApprovalWarning = true;
                    self.warningMessageScenarios.deliquentWarning = false;

                    if (data.data.paymentTakeAction.toUpperCase() === "VIEW") {
                        if (self.cachedProgram.program.userEntitlement.viewPayment.toUpperCase() !== "TRUE") {
                            self.warningMessageScenarios.paymentApprovalWarning = false;
                        }

                        self.warningMessageText(self.verbiage.viewPaymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.viewPaymentLabel);
                    } else if (data.data.paymentTakeAction.toUpperCase() === "APPROVE") {
                        if (self.cachedProgram.program.userEntitlement.viewPayment.toUpperCase() !== "TRUE" && self.cachedProgram.program.userEntitlement.paymentApproval.toUpperCase() !== "TRUE") {
                            self.warningMessageScenarios.paymentApprovalWarning = false;
                        }

                        self.warningMessageText(self.verbiage.paymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.approvePaymentLabel);
                    } else {
                        self.warningMessageText(self.verbiage.remindPaymentApprovalWarningMessage);
                        self.takeActionText(self.verbiage.sendReminderLabel);
                    }
                } else {
                    if (!self.isBankUser() && self.cachedProgram.program.userEntitlement.createEditPayment.toUpperCase() === 'TRUE' && self.cachedProgram.program.controlCard.account.paymentPastDue.toUpperCase() === "TRUE") {
                        if (self.checkDeliquentWarning) {
                            self.warningMessageScenarios.deliquentWarning = true;
                            self.warningMessageScenarios.paymentApprovalWarning = false;

                            self.warningMessageText(self.verbiage.deliquentWarningMessage);
                            self.takeActionText(self.verbiage.makePaymentLabel);
                        }
                    }
                }

                for (index = 0; index < util.showWarningMessages.length; index += 1) {
                    if (util.showWarningMessages[index].program === self.cachedProgram.program.companyId) {
                        util.showWarningMessages[index].displayDeliquentWarningMessage = self.warningMessageScenarios.deliquentWarning;
                        util.showWarningMessages[index].displayPaymentApprovalWarningMessage = self.warningMessageScenarios.paymentApprovalWarning;

                        util.showWarningMessages[index].warningMessageText = self.warningMessageText();
                        util.showWarningMessages[index].takeActionText = self.takeActionText();

                        util.showWarningMessages[index].notificationsCount = self.notificationCount();
                        util.showWarningMessages[index].paymentsApprovalCount = self.paymentsApprovalCount();
                    }
                }

                /*
                 if (self.cachedProgram.program.controlCard.account.companyLimit === undefined) {
                 self.cachedProgram.program.controlCard.account.companyLimit = self.cachedProgram.program.companyLimit;
                 }
                 */

                self.generateDonut(self.cachedProgram.program.controlCard.account);

                self.getCachedAccountView(self.cachedProgram.program);
            }
        };

        self.setEntitlementObj = function (item) {
            var entObject = {},
                programEntitlement = item.program.programEntitlement;

            self.programData = item;
            self.cardHolderChosen.controlCardProgram = item.program;
            entObject.managePayment = (self.isBankUser()) ? true : (item.program.userEntitlement.createEditPayment.toUpperCase() === "FALSE") ? false : true;
            entObject.reqIncrease = true;
            entObject.manageAcount = (self.isBankUser()) ? true : (item.program.userEntitlement.ownPaymentAccount.toUpperCase() === "FALSE") ? false : true;
            entObject.openCard = (self.isBankUser()) ? true : (item.program.userEntitlement.openNewCard.toUpperCase() === "FALSE") ? false : true;
            entObject.changeStatus = (self.isBankUser()) ? true : (item.program.userEntitlement.statusChange.toUpperCase() === "FALSE") ? false : true;
            entObject.manageSpend = (self.isBankUser()) ? 'disabled' : (item.program.userEntitlement.cardLimitChange.toUpperCase() === "FALSE") ? false : (item.program.userEntitlement.cardLimitChange.toUpperCase() === "DISABLE") ? 'disabled' : true;

            //if (!self.isBankUser()) {
            if ((programEntitlement.limitApproval.toUpperCase() === "TRUE" || programEntitlement.newCardApproval.toUpperCase() === "TRUE") && (item.program.userEntitlement && (item.program.userEntitlement.openNewCard.toUpperCase() === "TRUE" || item.program.userEntitlement.cardLimitChange.toUpperCase() === "TRUE"))) {
                self.showPendingMaintenance = true;
            } else {
                self.showPendingMaintenance = false;
            }

            if (item.program.userEntitlement && item.program.userEntitlement.viewPayment.toUpperCase() === "FALSE") {
                $('[data-svb-cc-module="paymentactivity"]').addClass('svb-ca-inactive').addClass('unselectable');
            } else {
                $('[data-svb-cc-module="paymentactivity"]').removeClass('svb-ca-inactive').removeClass('unselectable');
            }
            //}

            util.userEntitlementsObject = entObject;
            self.entitlementObject(entObject);
            self.actions(self.getActionsList(entObject));
            self.actionsRender(true);
        };

        self.setNotificationIcon = function () {
            if ((self.programData.program.userEntitlement) !== undefined && (self.programData.program.userEntitlement.limitApproval === "true" || self.programData.program.userEntitlement.newCardApproval === "true")) {
                self.notificationIcon(true);
            } else {
                self.notificationIcon(false);
            }
        };

        self.selectedProgramCompute = ko.computed(function () {
            var i = 0,
                userEntitlement = {};

            if (self.selectedProgram()) {
                util.table = util.table || {};
                util.table.dropdownChange = true;
                self.fetchedControlCard = false;

                self.programInfoFail(false);

                $('[data-svb-cc-module="paymentactivity"]').removeClass('svb-ca-inactive').removeClass('unselectable');
                $('[data-svb-cc-module="cardholder"]').removeClass('svb-ca-inactive').removeClass('unselectable');

                var tempEntitlProgram = util.entitledPrograms;

                util.selectedProgram = self.selectedProgram();
                util.currentProgramId = util.selectedProgram.id;

                util.allCardAccountDetails = [];

                if (self.isBankUser() === undefined) {
                    if (util.isBankUser !== undefined) {
                        self.isBankUser(util.isBankUser);
                    } else {
                        self.isBankUser(true);
                    }
                }

                for (i = 0; i < util.entitledPrograms.length; i++) {
                    if (util.selectedProgram.id === util.entitledPrograms[i].program.companyId) {
                        if (util.entitledPrograms[i].program.hasOwnProperty('subAccount') && util.entitledPrograms[i].program.hasOwnProperty('controlCard')) {
                            self.cachedProgram = util.entitledPrograms[i];
                            self.companyId = util.selectedProgram.id;
                            break;
                        } else {
                            self.cachedProgram = undefined;
                        }
                    }
                }

                util.paymentAccountsCall = true;

                $('[data-svb-cc-module="cardholder"]').removeAttr('style');
                $('[data-svb-cc-module="paymentactivity"]').removeAttr('style');

                if (!self.cachedProgram) {
                    self.entitlementObject({});
                    self.actionsRender(false);
                    util.allProgramAccounts = [];
                    self.loaderStatus(true);
                    self.loaderModule("ca-overview");

                    for (i = 0; i < tempEntitlProgram.length; i++) {
                        var item = tempEntitlProgram[i];

                        if (self.selectedProgram().id === item.program.companyId) {
                            userEntitlement = item.program.userEntitlement;

                            self.totalAccount = 0;

                            self.setEntitlementObj(item);

                            util.controlCardProgram = item.program;

                            self.companyViewAccountReqData = self.companyViewReq(item, self.totalAccount);

                            self.notificationReq = self.paymentNotificationReq(item, self.totalAccount);

                            //var programEntitlement = item.program.programEntitlement;

                            if (!self.isBankUser() && (userEntitlement.paymentApproval.toUpperCase() === "TRUE" || userEntitlement.limitApproval.toUpperCase() === "TRUE" || userEntitlement.newCardApproval.toUpperCase() === "TRUE" || userEntitlement.viewPayment.toUpperCase() === "TRUE")) {
                                AJAX.getProgramNotification(self.notificationReq, self.notificationRes);
                            } else {
                                if (util.isBankUser) {
                                    //$('[data-svb-cc-module="paymentactivity"]').addClass('svb-ca-inactive').addClass('unselectable');
                                    //$('[data-svb-cc-module="cardholder"]').addClass('svb-ca-inactive').addClass('unselectable');
                                }

                                self.warningMessageScenarios.paymentApprovalWarning = false;
                                self.warningMessageScenarios.deliquentWarning = false;

                                self.checkDeliquentWarning = true;
                            }

                            AJAX.getTableData(self.companyViewAccountReqData, self.getCompanyViewAccountRes);

                            //  self.generateDonut(item.program);

                            break;
                        }
                    }
                } else {
                    if ($('.svb-ca-loader-container').length) {
                        $('.svb-ca-initial-loader').removeClass("overlay-active");
                        $('#svb-ca-initial-indicator').removeClass("svb-processing-indicator");
                        $('.svb-ca-loader-container').remove();
                    }

                    self.setEntitlementObj(self.cachedProgram);
                    userEntitlement = self.cachedProgram.program.userEntitlement;

                    self.cardHolderChosen.controlCard = self.cachedProgram.program.controlCard;
                    self.cardHolderChosen.subAccounts = self.cachedProgram.program.subAccount;

                    util.controlCard = self.cachedProgram.program.controlCard;
                    util.subAccounts = self.cachedProgram.program.subAccount;
                    util.controlCardProgram = self.cachedProgram.program;

                    util.allProgramAccounts = [];

                    util.allProgramAccounts.push(self.cachedProgram.program.controlCard);
                    util.allProgramAccounts.push.apply(util.allProgramAccounts, self.cachedProgram.program.subAccount);

                    self.notificationReq = self.paymentNotificationReq(self.cachedProgram, self.totalAccount);

                    //var programEntitlement = self.cachedProgram.program.programEntitlement;

                    if (!self.isBankUser() && (userEntitlement.paymentApproval.toUpperCase() === "TRUE" || userEntitlement.limitApproval.toUpperCase() === "TRUE" || userEntitlement.newCardApproval.toUpperCase() === "TRUE" || userEntitlement.viewPayment.toUpperCase() === "TRUE")) {
                        self.loaderStatus(true);
                        self.loaderModule("ca-overview");
                        AJAX.getProgramNotification(self.notificationReq, self.refreshNotificationRes);
                    } else {
                        if (util.isBankUser) {
                            //$('[data-svb-cc-module="paymentactivity"]').addClass('svb-ca-inactive').addClass('unselectable');
                            //$('[data-svb-cc-module="cardholder"]').addClass('svb-ca-inactive').addClass('unselectable');
                        }

                        self.warningMessageScenarios.paymentApprovalWarning = false;
                        self.warningMessageScenarios.deliquentWarning = false;
                        self.checkDeliquentWarning = true;

                        if (!self.isBankUser() && self.cachedProgram.program.userEntitlement.createEditPayment.toUpperCase() === 'TRUE' && self.cachedProgram.program.controlCard.account.paymentPastDue.toUpperCase() === "TRUE") {
                            if (self.checkDeliquentWarning) {
                                self.warningMessageScenarios.deliquentWarning = true;
                                self.warningMessageScenarios.paymentApprovalWarning = false;
                                self.warningMessageText(self.verbiage.deliquentWarningMessage);
                                self.takeActionText(self.verbiage.makePaymentLabel);
                            }
                        }

                        for (var index = 0; index < util.showWarningMessages.length; index += 1) {
                            if (util.showWarningMessages[index].program === self.cachedProgram.program.companyId) {
                                util.showWarningMessages[index].displayDeliquentWarningMessage = self.warningMessageScenarios.deliquentWarning;
                                util.showWarningMessages[index].displayPaymentApprovalWarningMessage = self.warningMessageScenarios.paymentApprovalWarning;

                                util.showWarningMessages[index].warningMessageText = self.warningMessageText();
                                util.showWarningMessages[index].takeActionText = self.takeActionText();

                                util.showWarningMessages[index].notificationsCount = self.notificationCount();
                                util.showWarningMessages[index].paymentsApprovalCount = self.paymentsApprovalCount();
                            }
                        }

                        self.generateDonut(self.cachedProgram.program.controlCard.account);

                        self.getCachedAccountView(self.cachedProgram.program);
                    }
                }

                self.setNotificationIcon();
            }
            self.resetValues();
        });

        self.warningContent = ko.pureComputed(function () {
            if (self.warningMessage()) {
                return;
            }
        });

        self.navigateCardHolder = function () {
            //if (!util.isBankUser) {
            self.cardHolderChosen.ceid = self.cardHolderChosen.controlCard.account.ceid;
            self.cardHolderChosen.notification = self.notificationIcon;
            self.cardHolderChosen.showPending = self.showPendingMaintenance;

            require(["navigation", "mockConfig"], function (navigation) {
                navigation("cardholder", self.cardHolderChosen);
            });
            //}
        };

        self.openModalContainer = function () {
            if (!util.isBankUser) {
                self.enablePayments(false);
                var params = {};
                params.tab = "tab1";
                params.initModule = "ca-overview";
                params.enable = self.enablePayments;
                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("payments", params);
                });
            }
        };

        //Invocation point of pending Approval
        self.openPendingApproval = function () {
            var params = {
                show: "approval",
                from: "overview",
                tabName: "pendingApproval",
                showApproval: self.notificationIcon(),
                showMaintenance: self.showPendingMaintenance
            };

            require(["navigation", "mockConfig"], function (navigation) {
                navigation("pendingapproval", params);
            });
        };

        /*self.fetchManageSpendDetails = function(response) {
            var params = {};

            params.tab = "tab1";
            params.initModule = "ca-overview";
            params.from = "overview";
            params.enable = self.enableManageSpend;
            params.cardSelected = self.cardSelected;
            params.response = response;
            params.prin = self.programData.program.prin;
            params.notification = self.notificationIcon;
            params.showPending = self.showPendingMaintenance;

            require(["navigation", "mockConfig"], function (navigation) {
                navigation("manageSpend", params);
            });

            self.loaderStatus(false);
        };*/

        self.openManageSpend = function (element, event) {
            if ((event.target.className !== "change-limit disabled")) {

                var params = {};
                self.enableManageSpend(false);
                params.tab = "tab1";
                params.initModule = "ca-overview";
                params.from = "overview";
                params.enable = self.enableManageSpend;
                params.cardSelected = self.cardSelected;
                params.prin = self.programData.program.prin;
                params.notification = self.notificationIcon;
                params.showPending = self.showPendingMaintenance;
                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("manageSpend", params);
                });
            }
        };

        self.selectedCard.subscribe(function (cardHolderId) {
            self.cardHolderChosen.ceid = cardHolderId;
            self.cardHolderChosen.notification = self.notificationIcon;
            self.cardHolderChosen.showPending = self.showPendingMaintenance;

            self.loaderStatus(false);
            self.loaderModule("ca-card-holder");
            require(["navigation", "mockConfig"], function (navigation) {
                navigation("cardholder", self.cardHolderChosen);
            });
        });

        self.loadPermanentIncrease = function () {
            if (!util.isBankUser) {
                var params = {};
                params.initModule = "ca-overview";
                self.loaderModule("ca-permanent-increase");
                require(["navigation", "mockConfig"], function (navigation) {
                    navigation("permanentincrease", params);
                });
            }
        };

        self.openChangeStatusWindow = function () {
            var params = {};
            self.enableCardStatus(false);
            params.initModule = "ca-overview";
            params.cardSelected = self.cardSelected;
            params.enable = self.enableCardStatus;

            require(["navigation", "mockConfig"], function (navigation) {
                navigation("cardstatusoverlay", params);
            });
        };

        self.loadLostStolen = function (data, element) {
            var params = {};
            self.enableLostStolen(false);
            params.enable = self.enableLostStolen;
            params.initModule = "ca-overview";
            //self.loaderStatus(true);
            params.cardSelected = self.cardSelected;
            params.navigationFromCardHolder = false;
            if ($(element.currentTarget).hasClass('replace')) {
                params.replace = true;
            } else {
                params.replace = false;
            }
            require(["navigation", "mockConfig"], function (navigation) {
                navigation("reportstolencard", params);
            });
        };

        self.viewAccountAdministration = function (element, event) {

        };

        self.makePayment = function (element, event) {
            var params = {};
            if (!($(event.currentTarget).hasClass('greyout'))) {
                if (element.controlAutopay().toUpperCase() !== 'DISABLED') {
                    $('.ca-content').remove();
                    params.initModule = "ca-overview";
                    require(["navigation", "mockConfig"], function (navigation) {
                        navigation("paymentactivity", params);
                    });
                } else {
                    if ($('.svb-cardsAdmin').find('ca-payment').length === 0) {
                        params.initModule = "ca-overview";
                        params.tab = "tab2";
                        require(["navigation", "mockConfig"], function (navigation) {
                            navigation("payments", params);
                        });
                    }
                }
            }
        };


        if (!util.entitledPrograms) {
            if (tempUtil) {
                var responseStatus;
                if (tempUtil.data.result && tempUtil.data.result.messageCode) {
                    responseStatus = tempUtil.data.result.messageCode;
                    if (responseStatus !== "0") {
                        self.serverFail(true);
                        util.serverFail = true;
                        self.loaderStatus(false);
                        ko.cleanNode($('.ca-overview')[0]);
                        ko.applyBindings(self, $('.ca-overview')[0]);
                        $('.svb-cardsAdmin').show();
                        if ($('.svb-ca-loader-container').length) {
                            $('.svb-ca-initial-loader').removeClass("overlay-active");
                            $('#svb-ca-initial-indicator').removeClass("svb-processing-indicator");
                            $('.svb-ca-loader-container').remove();
                        }
                        return;

                    }
                }
                util.entitledPrograms = tempUtil.data.entitledPrograms;
                util.miscInfo = tempUtil.data.misc;
                util.navigate = tempUtil.data.navigation;

                if (tempUtil.data.userType !== undefined && tempUtil.data.userType.toUpperCase() === "BANK") {
                    self.isBankUser(true);

                    util.isBankUser = true;
                } else {
                    self.isBankUser(false);

                    util.isBankUser = false;
                }

                util.companyAccountSeqLimit = tempUtil.data.compAccntSeq;
                delete window.tempUtil;

            }
            if (!self.serverFail()) {
                if (window.caNavigationObj) {
                    util.navigateTo = window.caNavigationObj;
                    delete window.caNavigationObj;
                }
            }

        }
        if (!self.serverFail()) {
            self.entitledPrograms(util.entitledPrograms);
        }
        // return self;
    };

    return Overview;
});