define("app/Common/extenders", ["knockout"], function (ko) {
    ko.extenders.noLessThan = function (target, precision) {
        target.hasError = ko.observable(false);
        target.validationMessage = ko.observable();
        function validate(newValue) {
            var current = parseInt(target()),
                newValueObt = parseInt(newValue),
                compareValue = parseInt(precision);
            if (newValueObt < compareValue) {
                target.validationMessage("Please enter greater value");
                target.hasError(true);
            } else {
                target.hasError(false);
            }
        }
        //initial validation
        validate(target());     //validate whenever the value changes
        target.subscribe(validate);    // return the original observable
        return target;
    };

});