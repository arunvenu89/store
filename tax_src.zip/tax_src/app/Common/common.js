/* global document, event */
define(["jquery", "knockout", "util"], function ($, ko, util) {
    var common = {
        sortData: function (data, prop) {
            var len = data.length;
            for (var i = len - 1; i >= 0; i--) {
                for (var j = 1; j <= i; j++) {
                    if (data[j - 1][prop] > data[j][prop]) {
                        var temp = data[j - 1];
                        data[j - 1] = data[j];
                        data[j] = temp;
                    }
                }
            }

            return data;
        },

        showDeliquentWarning: function (selectedProgram) {
            var len = util.showWarningMessages.length;

            for (var i = 0; i < len; i += 1) {
                var programItem = util.showWarningMessages[i];

                if (String(programItem.program) === String(selectedProgram)) {
                    if (programItem.displayDeliquentWarningMessage) {
                        return true;
                    }
                }
            }
        },

        setDeliquentWarning: function (value) {
            var len = util.showWarningMessages.length;

            for (var i = 0; i < len; i += 1) {
                var programItem = util.showWarningMessages[i];

                if (String(programItem.program) === String(util.currentProgramId)) {
                    programItem.displayDeliquentWarningMessage = value;
                }
            }
        },

        getCardData: function (accountNumber) {
            var len = util.allProgramAccounts.length;

            for (var i = 0; i < len; i += 1) {
                var accountItem = util.allProgramAccounts[i];

                if (String(accountItem.account.lastFourDigit) === String(accountNumber)) {
                    accountItem.account.ceid = util.ceid;
                    return accountItem;
                }
            }
        },

        isEmptyVal: function (val) {
            if (val === undefined) {
                return true;
            }
            if (val === null) {
                return true;
            }
            if (val === "") {
                return true;
            }
        },

        closePaymentModal: function () {
            $('.ca-payment').remove();
            $('.ca-content').show();
        },

        validateEmail: function (val) {
            //temporary check and seting value for validation
            if(val === ""){
                return true;
            }

            var result =  (
                // jquery validate regex - thanks Scott Gonzalez
                /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(val)
            );

            return result;
        },

        format : function (date, type) {
            var format = '',
                month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                shortMonth = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                dd = '',
                mm = '',
                yy = '';

            if (type === 'MMM dd') {
                dd = date.getDate();
                mm = date.getMonth();

                if (dd < 10) {
                    dd = '0' + dd;
                }

                format = shortMonth[mm] + ' ' + dd;
            } else if (type === 'MMMM dd, yyyy') {
                dd = date.getDate();
                mm = date.getMonth();
                yy = date.getFullYear();

                if (dd < 10) {
                    dd = '0' + dd;
                }

                format = month[mm] + ' ' + dd + ', ' + yy;
            } else if (type === 'MM/dd/yyyy') {
                dd = date.getDate();
                mm = date.getMonth() + 1;
                yy = date.getFullYear();

                format = '' + mm + '/' + dd + '/' + yy;
            } else if (type === 'MMMM dd') {
                dd = date.getDate();
                mm = date.getMonth();

                if (dd < 10) {
                    dd = '0' + dd;
                }

                format = month[mm] + ' ' + dd;
            } else if (type === 'MMM dd, yyyy') {
                dd = date.getDate();
                mm = date.getMonth();
                yy = date.getFullYear();

                if (dd < 10) {
                    dd = '0' + dd;
                }

                format = shortMonth[mm] + ' ' + dd + ', ' + yy;
            } else if (type === 'MMMM d, yyyy') {

            }

            return format;
        },

        //To format the given date
        formatDate : function (inputDate, pattern) {
            if (!inputDate) {
                return null;
            }

            var checkPST = inputDate.split('-'),
                inputLength = inputDate.length,
                checkSlash = inputDate.split('/'),
                date = null,
                mm = null,
                dd = null,
                yy = null,
                format = null;

            if (checkPST.length === 3) {
                date = new Date(inputDate);
            } else if (checkPST.length === 4) {
                date = new Date();
                mm = parseInt(checkPST[1], 10) - parseInt(1, 10);
                date.setFullYear(parseInt(checkPST[0], 10));

                date.setMonth(11);
                date.setDate(31);

                date.setDate(parseInt(checkPST[2], 10));
                date.setMonth(mm);
            } else {
                date = new Date();
                if (checkSlash.length === 3) {
                    date = new Date();
                    mm = parseInt(checkSlash[0], 10) - parseInt(1, 10);
                    date.setFullYear(parseInt(checkSlash[2], 10));

                    date.setMonth(11);
                    date.setDate(31);

                    date.setDate(parseInt(checkSlash[1], 10));
                    date.setMonth(mm);
                } else if (inputLength === 4) {
                    mm = inputDate.charAt(0) + inputDate.charAt(1);
                    mm = parseInt(mm, 10) - parseInt(1, 10);
                    dd = inputDate.charAt(2) + inputDate.charAt(3);
                    if (dd > "00" || mm > 0) {
                        date.setMonth(11);
                        date.setDate(31);

                        date.setDate(parseInt(dd, 10));
                        date.setMonth(mm);
                    } else {
                        date = null;
                    }
                } else if (inputLength === 6) {
                    yy = parseInt((inputDate.charAt(0) + inputDate.charAt(1)), 10) + parseInt(2000, 10);
                    mm = parseInt((inputDate.charAt(2) + inputDate.charAt(3)), 10);
                    dd = parseInt((inputDate.charAt(4) + inputDate.charAt(5)), 10);

                    mm = parseInt(mm, 10) - parseInt(1, 10);

                    date.setFullYear(yy);

                    date.setMonth(11);
                    date.setDate(31);

                    date.setDate(dd);
                    date.setMonth(mm);
                } else if (inputLength === 8) {
                    yy = parseInt((inputDate.charAt(0) + inputDate.charAt(1) + inputDate.charAt(2) + inputDate.charAt(3)), 10);
                    mm = parseInt((inputDate.charAt(4) + inputDate.charAt(5)), 10);
                    dd = parseInt((inputDate.charAt(6) + inputDate.charAt(7)), 10);

                    mm = parseInt(mm, 10) - parseInt(1, 10);

                    date.setFullYear(yy);

                    date.setMonth(11);
                    date.setDate(31);

                    date.setDate(dd);
                    date.setMonth(mm);
                }
            }

            /*  Time Patterns:
             MMM DD			-------------	Aug 05
             MMMM DD, YYYY	-------------	August 05, 2014
             MM/DD/YYYY		-------------	08/05/2014
             MMMM DD			-------------	August 05
             MMM DD, YYYY	-------------	Aug 05, 2014
             MMMM D, YYYY    -------------   August 5, 2014
            */

            if (date !== null) {
                if (pattern === 'MMM DD') {
                    format = common.format(date, 'MMM dd');
                } else if (pattern === 'MMMM DD, YYYY') {
                    format = common.format(date, 'MMMM dd, yyyy');
                } else if (pattern === 'MM/DD/YYYY') {
                    format = common.format(date, 'MM/dd/yyyy');
                } else if (pattern === 'MMMM DD') {
                    format = common.format(date, 'MMMM dd');
                } else if (pattern === 'MMM DD, YYYY') {
                    format = common.format(date, 'MMM dd, yyyy');
                } else if (pattern === 'MMMM D, YYYY') {
                    format = common.format(date, 'MMMM d, yyyy');
                }
            } else {
                format = date;
            }

            return format;
        },

        getNextBusinessDay : function (date, n) {
            var nxtBusDay = new Date(date);
            nxtBusDay.setHours(0, 0, 0, 0); // for time comparison.

            // day to next day
            if(n!==0){
                nxtBusDay.setDate(nxtBusDay.getDate() + 1);
            }

            var holidaysList = util.miscInfo.holidays;
            var result = false;
            $.each(holidaysList, function (idx, val) {
                if (new Date(val).getTime() === nxtBusDay.getTime()) {
                    result = true;
                }
            });

            if (nxtBusDay.getDay() === 0 || nxtBusDay.getDay() === 6) {
                result = true;
            }

            if (result) {
                nxtBusDay = common.getNextBusinessDay(nxtBusDay);
            } else {
                return nxtBusDay;
            }

            return nxtBusDay;
        },

        nthBusinessDay : function (date, n) {
            var ret;

            if (n === undefined) {
                n = 0;
            }

            for (var i = 0; i <= n; i++) {
                if (ret) {
                    date = ret;
                }
                ret = common.getNextBusinessDay(date, n);
            }

            return ret;
        },

        fireEvent: function (element,event){
            var evt = null;

            if (document.createEventObject){
                // dispatch for IE
                evt = document.createEventObject();
                return element.fireEvent('on'+event,evt);
            } else{
                // dispatch for firefox + others
                evt = document.createEvent("HTMLEvents");
                evt.initEvent(event, true, true ); // event type,bubbling,cancelable
                return !element.dispatchEvent(evt);
            }
        },

        findMaximumDaysOfMonth: function (month, year) {
            var monthArray = util.monthArray;

            if (month === 1) {
                if (year % 4 === 0) {
                    return monthArray[1][1];
                } else {
                    return monthArray[1][0];
                }
            } else {
                return monthArray[month];
            }
        },

        parseAmount : function(amount) {
            var amountTmp = parseFloat(amount);

            if (amountTmp < 0) {
                amountTmp = amountTmp * -1;
                amountTmp = amountTmp.toFixed(2);
                amountTmp = '(' + amountTmp + ')';
            } else {
                amountTmp = amountTmp.toFixed(2);
            }

            amountTmp = amountTmp.replace(/\B(?=(\d{3})+(?!\d))/g, ",");

            return amountTmp;
        }
    };

    return common;
});