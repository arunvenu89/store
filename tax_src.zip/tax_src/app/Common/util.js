/* jshint browser: true */
define(["jquery"], function($) {
    var self = this;
    self.chromeCtrlEvent = function(element, event) {
        return (event.ctrlKey && (event.keyCode === 86 || event.keyCode === 118));
    };
    self.firefoxCtrlEvent = function(element, event) {
        return (event.ctrlKey && (event.which === 86 || event.which === 118));
    };

    self.chromeIsShiftkey = function(element, event) {
        return (event.shiftKey && (event.keyCode > 46 && event.keyCode < 58));
    };
    self.firefoxIsShiftkey = function(element, event) {
        return (event.shiftKey && (event.which > 46 && event.which < 58));
    };
    var util = {
        verbiage: {
            serverErrorMessage: "We apologize, we are having difficulties retrieving your card account details.",
            contactServiceInstructionLabel: "Please try again. If this issue continues please contact ",
            clientSupportLabel: "SVB Card Services",
            nextButton: "Next",
            confirmButton: "Confirm",
            doneButton: "Done",
            saveButton: "Save",
            editButton: "Edit",
            cancelButton: "Cancel",
            updateButton: 'Update',
            makePaymentButton: "Make a Payment",
            reportLostStolenButton: "Report Lost/Stolen",
            replaceCardButton: "Replace Card",
            changeCardStatusButton: "Change Status",
            manageSpendButton: "Manage Spend",
            showActivityButton: "Show Activity",
            yesButton: "Yes",
            noButton: "No",
            goButton: "Go",
            continueButton: "Continue",
            setUpAutoPaymentButton: 'Set up Auto Payment',
            approveButton: 'Approve',
            rejectButton: 'Reject',
            okButton: "Ok",
            makePaymentLabel: "Make Payment",
            sendReminderLabel: "Send Reminder",
            approvePaymentLabel: "Approve Payment",
            viewPaymentLabel: "View Payment",
            selectedLabel: "Selected",

            forLabel: "for",
            atLabel: "at",
            novemberLabel: "November",
            viewEditLabel: "view/edit",
            autoLabel: 'Auto',
            thisLabel: "This",
            theLabel: "The",
            firstLabel: "first",
            yourLabel: "Your",
            fromLabel: "From",

            activityDateRangeToolTipText: 'Activity available for the past 13 months. Search here by entering a specific date range or select the Statement tab to search by defined statement periods.',
            currentBalanceToolTipText: "This balance does not include pending authorizations.",
            fromPaymentAccountToolTipText: 'Select the bank account you would like this payment to debit from',
            fromPayAccountAutoPayToolTipText1: "Select your Payment Account or Add New Payment Account.",
            fromPayAccountAutoPayToolTipText2: "Why are certain Payment Accounts disabled?",
            fromPayAccountAutoPayToolTipText3: "This account currently has Auto Payment scheduled. You must first cancel Auto Payment to enable other Payment Accounts.",

            searchTransactionsPlaceHolderText: 'Search e.g. keyword, amount',
            searchPaymentHistoryPlaceHolderText: 'Search (e.g. keyword, amount)',

            noAuthTransactionsContentText: "Sorry, there are no Authorizations to show that match the current search parameters.",
            noPostedTransactionsContentText: "Sorry, there are no Transactions to show that match the current search parameters.",
            noBankNameSearchInitialContentText: "Enter search criteria on the left side of page.",
            noBankNameSearchContentText: "There are no results.",

            autoPayEnabledWarningText: "Auto Payment - Next payment",
            pendingPaymentApprovalWarningText: "Approval is required in order to make this payment by",
            cutOffTimeWarningText1: 'Cutoff time for same-day payments is',
            cutOffTimeWarningText2: 'Payments made after that time will be processed on the next business day.',
            cutOffTimeWarningText3: 'Payments made by you can only be modified by you. Other card account managers can only view or cancel (prior to the payment processing deadline) payments you have created.',
            makePaymentBeforeWarningText: "Make your Payment before",
            paymentAlreadyExistsWarningText1: "A payment has already been scheduled for",
            paymentAlreadyExistsWarningText2: "Please select another day, or click here to",
            paymentAlreadyExistsWarningText3: "your existing payment(s).",
            paymentAlreadyExistsWarningText4: "Cut-off time crossed for today.",
            paymentAlreadyExistsWarningText5: "Payment date should not be greater than 60 days.",
            paymentVerificationWarningText1: 'We are sorry. Changes to this',
            paymentVerificationWarningText2: 'Payment are not allowed at this time. Please contact',
            paymentVerificationWarningText3: 'for further assistance',
            paymentVerificationWarningText4: 'The first payment date for this Auto Payment has been set to start after the closing of your current statement.',

            pendingPaymentApprovalInstructionText1: 'Please take action on the payment request below. Same day payments require approval before the',
            pendingPaymentApprovalInstructionText2: 'deadline. Payments approved after the deadline will be processed the next business day.',
            paymentConfirmationInstructionText1: "Payment request has been received on",
            paymentConfirmationInstructionText2: "and is subject to verification",
            paymentConfirmationInstructionText3: "payment will be processed on",
            paymentConfirmationInstructionText4: "and will be reflected in your account activity on the same day",
            autoPaymentRejectInstructionText: "Are you sure you want to cancel this monthly Auto Payment?",
            singlePaymentRejectInstructionText: "Are you sure you want to cancel this payment?",
            paymentRejectConfirmationInstructionText: "Confirm that you want to cancel the following payment",

            requestIncreaseLabel: "Request Increase",
            companyLimitLabel: "Company Limit",
            cardLimitLabel: "Card Limit",
            currentBalanceLabel: "Current Balance",
            pendingLabel: "Pending",
            availableCreditLabel: "Available Credit",
            availableSpendLabel: "Available Spend",
            companyLabel: "Company",
            controlAccountLabel: "Control Account",
            companyNameLabel: "Company Name",
            companyIdLabel: "Company ID",
            billingTypeLabel: "Billing Type",
            lastStmtDateLabel: "Last Statement Date",
            lastStmtBalLabel: "Last Statement Balance",
            lastPaymentPostedLabel: "Last Payment Posted",
            minPaymentDueLabel: "Minimum Payment Due",
            paymentDueDateLabel: "Payment Due Date",
            autoPaymentLabel: "Auto Payment",
            cardNumberLabel: "Card Number",
            cardHolderLabel: "Card Holder",
            minimumDueLabel: "Minimum Due",
            closingDateLabel: "Closing Date",
            paymentDueLabel: "Payment due",
            cardStatusLabel: "Card Status",
            replacementCardLabel: "Replacement Card",
            balanceAsOfLabel: "Balance as of",
            requestLabel: "Request",
            lostOrStolenLabel: "Lost/Stolen Card",
            reportLabel: "Report",
            statementsDownloadLabel: "Statements & Downloads",
            viewLabel: "View",
            accountAdministrationLabel: "Account Administration",

            dateRangeLabel: "Date Range",
            statementLabel: "Statement",
            toLabel: "to",
            moreFilterOptionsLabel: "More Filter Options",
            ofLabel: "of",
            previousLabel: "« Prev",
            nextLabel: "Next »",
            totalResultsText: "total results",

            accountLabel: "Account",
            accountsLabel: "Accounts",
            deliquentWarningMessage: "Your account is past due, would you like to make a payment?",
            paymentApprovalWarningMessage: "You have a pending payment to be approved, would you like to approve?",
            viewPaymentApprovalWarningMessage: "There are payments pending approval, would you like to view them?",
            remindPaymentApprovalWarningMessage: "Your payment is pending approval, would you like to send reminder?",
            All: "All",
            activeLabel: "Active",
            suspendedLabel: "Suspended",
            closedLabel: "Closed",
            ActiveCardholders: "Active Cardholders",
            ClosedCardholders: "Closed Cardholders",
            SuspendedCardholders: "Suspended Cardholders",
            reportLostStolen: "Reported Lost/Stolen",
            moreActionsLabel: "More Actions",
            newCardLabel: "Open a New Card",
            pendingMaintenanceRequestLabel: "Pending Maintenance Requests",
            statementsOrDownloadsLabel: "Statements/Downloads",
            managePaymentAccountsLabel: "Manage Payment Accounts",
            rewardsLabel: "Rewards",
            masterCardEasySavingsLabel: "Master Card Easy Savings",
            smartDataLabel: "Smart Data",

            activityLabel: "Activity for",
            closedCardLabel: "Card Closed",
            searchLabel: "Search",
            activityTypeLabel: "Activity Type",
            amountRangeLabel: "Amount Range",
            authTransactionsLabel: "Authorizations",
            postedTransactionsLabel: "Posted Transactions",
            transactionLabel: "Transaction",
            transactionsLabel: "Transactions",
            transactionDateLabel: "Transaction Date",
            descriptionLabel: "Description",
            amountLabel: "Amount",
            authDateLabel: "Authorization Date",
            authTimeLabel: "Authorization Time",
            authAmountLabel: "Authorization Amount",
            declinedReasonLabel: "Reason for decline",
            referenceNumberLabel: "Reference Number",
            postDateLabel: "Post Date",
            convertedFromLabel: "Converted From",
            conversionRateLabel: "Conversion Rate",
            conversionFeeLabel: "Conversion Fee",
            merchantNameLabel: "Merchant Name",
            mccLabel: "MCC",
            disputeChargeLabel: "Dispute Charge",
            cardHoldersLabel: 'CARDHOLDERS',
            creditTypeLabel: 'Credit(s)',
            debitTypeLabel: 'Debit(s)',
            activeCardHoldersLabel: "ACTIVE CARDHOLDERS",
            closedCardHoldersLabel: "CLOSED CARDHOLDERS",
            suspendedCardHoldersLabel: "SUSPENDED CARDHOLDERS",

            cardDisputeFormLabel: "Card Dispute Form",
            DisputeFormText: "Prior to submitting any dispute, SVB encourages you to contact the merchant directly. For your reference when communicating with the merchant, use the details of the transaction provided below.",
            DisputeFormText1: "We have received your request to dispute the transaction below. If additional details are needed, SVB will contact you. In the meantime, a letter will be mailed to the cardholder within 7-10 business days regarding the status of this request.",
            transactionPostDatelabel: "Transaction Posting Date",
            transactionAmountLable: "Transaction Amount",
            disputeAmountLabel: "Disputed Amount",
            participateTransactionsLabel: "Cardholder participated in transaction?",
            reasonForDisputeLabel: "Reason for Dispute",
            hasMerchantContactedLabel: "Has the merchant been contacted?",
            businessWithMerchantLabel: "Has the cardholder done business in the past with the merchant ?",
            disputeTextAreaContentLabel: "Please describe the dispute in detail, as well as any information regarding your communication with the merchant.",
            participateTransactionsOptionsLabel: "Did cardholder participate in the transaction?",
            disputedAmountErrorMsgText: "The amount entered is invalid.",
            disputeTextareaPlaceholder: "Include names, dates, times and the situation",
            submitButton: "Submit",
            cancelledRecurringTransLabel: "Cancelled Recurring Transaction",
            creditNotProcessedLabel: "Credit Not Processed",
            transAmtDiffLabel: "Transaction Amount Differs",
            goodsOrServiceLabel: "Goods or Services Not Received",
            defectiveNotasDescribedLabel: "Defective Not as Described",
            transNotAuthorizedLabel: "Transaction Not Authorized",
            duplicatTrasLabel: "Duplicate Transaction",
            otherLabel: "Other",
            disputeFormLabel: "dispute-form",

            paymentActivityLabel: "Payment Activity for",
            searchPaymentsLabel: "Search Payments",
            viewAutoPayOnlyText: "View Auto Payments Only",
            paymentAccountLabel: "Payment Account",

            singlePaymentLabel: 'Single Payment',
            paymentAccountsLabel: 'Payment Accounts',
            scheduledPaymentsLabel: 'Scheduled Payments',
            pendingApprovalLabel: 'Pending Approval',
            minimumBalanceLabel: 'Minimum Balance',
            lastStatementBalanceLabel: "Last Statement Balance",
            setAutoPaymentLabel: 'Set up Auto Payment',
            paymentForProgramLabel: 'Apply Payment to Account',
            autoPaymentDateLabel: 'First Payment Date',
            minimumLabel: 'Minimum',
            memoLabel: "Memo",
            editAutoPaymentLabel: 'Edit Auto Payment',
            futureMonthlyPaymentLabel: 'All future monthly payments',
            nextPaymentOnlyLabel: 'Next Payment only',
            editAutoPaymentDateLabel: 'Next Payment Date',
            editPaymentLabel: 'Edit Single Payment',
            editPaymentForProgramLabel: 'Pay Control Card',
            dateLabel: 'Date',
            setPaymentLabel: 'Make A Single Payment',
            autoPayDateDetailsLabel: 'Payment on',
            frequencyLabel: 'Frequency',
            monthlyLabel: 'Monthly',
            printConfirmationLabel: 'Print Confirmation',
            returnToOverviewLabel: 'Return to Overview',
            viewEditPaymentsLabel: 'View/Edit Payments',
            verifyPaymentLabel: 'Verify your details',
            paymentApprovalLabel: 'Payment Approval',
            importantLabel: 'Important',
            createdByLabel: 'Created By',
            additionalActionRequiredLabel: 'Additional Action Required',

            autoPayDateWarningText1: 'Payment will be processed two days',
            autoPayDateWarningText2: 'before payment due date',
            autoPayDateConfirmationWarningText: '2 days before payment due date',

            paymentMemoToolTipText: 'Use this field to include payment details. This information is visible to you only and will not be included with your payment',
            autoPaymentDateToolTipText: 'Auto Payment will always be processed two days before payment due date.',

            setAutoPaymentInstructionText: "Enter the Information below to make a payment for your Company Account.",
            otherAmountFootNoteInstructionText: 'Note: If amount entered is greater than your Current Balance on the processing date we will only apply your Current Balance as your payment amount.',
            editAutoPaymentInstructionText: 'Update the information below to change the current selections for all future monthly payments or the next payment only.',
            editPaymentInstructionText: 'Update the payment details below.',
            setPaymentInstructionText: 'Enter the Information below to make a payment for your Company Account.',
            autoPayDateInstructionText1: 'If the payment date ever falls on a weekend or a holiday',
            autoPayDateInstructionText2: "we'll make the payment on the next business day",
            verifyPaymentInstructionText: 'Verify the payment details below and click Confirm to submit the payment for processing.',
            addPaymentAccountInstructionText: 'Add, modify, or delete payment accounts for your individual use. You can save up to four payment accounts. Please note these payment accounts are for your use only and will not be visible to other card account managers.',
            
            downloadPopUpInstructionText: 'Downloading in progress. You may continue with your online card activity.',
            
            pendingApprovalNoteInstructionText: "Any auto payments approved after the deadline on the first payment date will be scheduled for next month's due date.",
            pendingApprovalText1: "This page includes all maintenance requests submitted by other card account managers that are pending your review and approval. Requests remain pending until a decision is provided.",
            pendingApprovalText2: "New card requests approved after 6:00 p.m. PT may delay expedited delivery by one business day.",
            pendingApprovalText3: "To view, edit and/or cancel your submitted requests, select the Pending Maintenance Requests tab above.",
            pendingApprovalVerifyText1: "Verify the decision of each request below. Once you have verified the status of each request, click the Confirm button at the bottom of the screen to submit each pending request.",
            pendingApprovalConfirmText1: "Changes submitted successfully. Spend and Cash Advance changes will be applied immediately.",
            pendingApprovalConfirmText2: "New Card Requests must be approved prior to 6 p.m. PT for expedited shipping requests to be accommodated.",
            permanentIncreaseConfirmationScreenForIncreaseCurrentCompanyLimit: "Thank you. We have received your request to increase your company limit. A member of your Relationship Team will contact you within 24 hours with the status of the request, and the next steps to complete it.",
            statusChangeCardStatusText1: "Manage the card status on this page. Cards can be suspended, reactivated or closed.",
            statusChangeCardStatusText2: 'When suspending a card, you have the option to assign temporary suspend dates. If dates are left blank, the card will be suspended until a card account manager reactivates the card.',
            statusChangeCardStatusText3: " Closing a card is permanent. Once closed, a card cannot be reactivated.",
            statusChangeCardStatusVerificationText: "Verify status changes below and click the Confirm button to process the request. All status changes are immediate (unless temporary dates are assigned to suspended cards).  ",
            statusChangeCardStatusConfirmationText1: "Card status changes have been submitted successfully.",
            statusChangeCardStatusConfirmationText2: "All status changes are immediate (unless temporary dates are assigned to suspended cards).",
            statusChangeRequestFailedComment: "Status change request failed.",
            statusChangeRequestFailedInstruction: " Please try again",
            statusChangeRequestFailedInstructionWithDot: " Please try again.",
            statusChangeRequestFailedContactInfo: "contact us.",
            contactCardInformation: "Card currently suspended. For more information regarding this card's suspension contact SVB Card Support at 1-866-553-3481 (Toll-Free) or 1-781-756-8155 (Local). 24 hours a day, 7 days a week.",
            contactCardInformationElite: "Card Currently Suspended For more information regarding this card's suspension contact SVB Elite Card Support at 1-866-940-5920 (Toll-Free) or 1-408-654-7720 (Local).24 hours a day, 7 days a week.",
            contactSupportServices: "Contact Support Services.",
            contactCardInfoForMultiProgram: "Contact SVB Card Support at 1-866-553-3481 (Toll-Free) or 1-781-756-8155 (Local)",
            contactCardInfoForElite: "Contact SVB Elite Card Support at 1-866-940-5920 (Toll-Free) or 1-408-654-7720 (Local).",
            suspendedTemporarily: "Temporary status dates are optional. If left blank, the new status will be applied to the cardholder permanently. The status can be changed at any time by selecting Change Status from the Overview page.",
            noResultsFound: "No results found for the provided search criteria",
            statementFor: "Statements For",
            noCardStatusRecords: "No results for the Card status",
            payDateMesageLine1: "Make your payment before",
            payDateMesageLine2: " to avoid late fees",
            stmtDesc: "View and download your monthly statement for the last 24 months. If you select multiple statements, they will download as a single ZIP file.",
            downloadDesc: "Import your credit card transaction detail into QuickBooks®, Quicken®, and other accounting applications. Use the Select File Format drop-down list to select a file format, then click the Download button.",
            formatOptions: "Format options: .CSV, .QBO, .QFX, .OFX and .PDF",
            stmtNoresult: "No Statements available at this time",
            successfullyUpdated: "All cards got updated successfully",
            partiallyUpdated: "cards are updated partially",
            failed: "Sorry, no cards are updated. Please try again in some time",
            allApproved: "Sorry, All Cards are approval are done by some one",
            partiallyApproved: "Some Card are already approved",
            suspiciousMsg: "Do you think this transaction is suspicious?",
            warningAlertMsg1: "Submit possible fraudulent transactions via the Report a Card Stolen page. Click the Go button to go to the  Report a Card Stolen page to submit all suspicious activity for review.",
            warningAlertMsg2: "We suggest that you contact the merchant prior to initiating a dispute. Doing so can help expedite the request and may be required. Click Continue to submit the dispute without contacting the merchant. Call SVB Card Support if you have any questions or wish to discuss your dispute before continuing.",
            tollfreeNo1: "1-866-940-5920",
            localNo1: "1-408-654-7720",
            tollfreeNo2: "1-866-553-3481",
            localNo2: "1-781-756-8155",
            tollFreeNoText: " (Toll-Free)",
            localText: " (Local)",

            spendLimitHomeScreen: "Manage your cardholders' spend limit. Changes in spend limits can be applied permanently or temporarily if applicable dates are provided. Cardholder spend limits revert to the current limit after applicable expiration dates.",
            spendLimitVerifyScreen: "Verify all new limits below. Click the Confirm button to apply limit changes.",
            spendLimitVerifyForApprovalScreen: "Verify all new limits below, and click the Submit for Approval button. New limits will not take affect until another card account manager approves the request(s).",
            spendLimitConfirmationForApprovalScreen: "Spend limit changes have been submitted for approval. To view, edit or cancel the request(s), visit the " + " ",
            cashAdvanceHomeScreen: "<p class='ca-verbiage-text'>Enabling cash advances allows cardholders to withdraw up to 20% of their spend limit in cash.</p>  <span class='ca-text-bold'>Important:</span> Cardholders should call: 1-888-891-2435 to setup a required PIN. Cash advance capabilities are not available until the cardholder's PIN is created.",
            cashAdvanceHomeEliteScreen: "<p class='ca-verbiage-text'>Enabling cash advances allows cardholders to withdraw up to 20% of their spend limit in cash.</p>  <span class='ca-text-bold'>Important:</span> Cardholders should call: 1-877-315-3483 to setup a required PIN. Cash advance capabilities are not available until the cardholder's PIN is created.",
            manageSpendTableTooltip: "Temporary limit dates are optional. If these fields are left blank, the new limit will be applied to the cardholder permanently. The limit can be changed at any time by selecting Manage Spend from the Overview page.",
            cashAdvanceVerifyForApprovalScreen: "Verify all new cash advance settings, and click the Submit for Approval button. New settings will not take affect until another card account manager approves the request(s).",
            cashAdvanceVerifyScreen: "Verify all new cash advance settings. Click the Confirm button to apply changes immediately.",
            cashAdvanceConfirmationScreen: "Cash advance settings have been submitted successfully.",
            cashAdvanceConfirmationForApprovalScreen: "Cash advance changes have been submitted for approval. To view, edit or cancel the request(s), visit the " + " ",
            spendLimitConfirmationScreen: "Spend limit changes submitted successfully.",
            maintenanceRequests: " maintenance requests pending approval.",
            maintenanceRequest: " maintenance request pending approval.",
            youHave: "You have ",
            page: " page.",
            noRequestToApprove: "There are no pending maintenance requests.",
            alreadyInPendingApproval: "Important: Spend Limit changes have already been requested for this cardholder and are pending approval by another card account manager.",
            alreadyInPendingApprovalCashAdvance: "Important: Cash Advance changes have already been requested for this cardholder and are pending approval by another card account manager.",
            companyLimitError: "New company limit requested must be greater than current company limit.",
            permanentIncrease: "Permanent Increase Request",
            newlimitInstruction: "Enter the total dollar amount of the new company limit you are requesting.",
            permanentIncreaseDesc: "Complete the information on this page to request a permanent increase for your company's limit.",
            newCardHeading: "New Card Request",
            newCardHeadingInformation: "Open one or multiple new cards here. All information is required unless otherwise indicated.",
            newCardHeadingPrivacyInfo: "For more details on how your information is used please read the ",
            newCardPrivacyLinkText: "SVB Privacy Policy.",
            editNewCardHeader: "Edit a Pending New Card",
            editNewCardHeaderInfo: " Modify the details of the pending new card request below. All fields are required unless otherwise indicated.",
            addCardholderLink: "+ Another Cardholder",
            verifyText: "Verify",
            confirmText: "Confirmation",
            verifyNewCardModuleHeaderAprrovalText1: "Verify new card details below for accuracy.",
            verifyNewCardModuleHeaderAprrovalText2: "This action requires a second approver and will be sent for approval.",
            confirmNewCardModuleHeaderApprovalText1: "The new card request(s) have been successfully submitted. This is your confirmation that SVB will issue cards to the following person(s) as you have directed.",
            confirmNewCardModuleHeaderApprovalText2: "New card requests require additional approval by another card account manager. Requests approved after 6:00 p.m. PT may delay the expedited delivery date by one business day.",
            verifyNewCardMainContentFirstParaHeading: "Right to Request Specific Reasons for Credit Denial",
            verifyNewCardMainContentFirstParaText: "If your application for business credit is denied, you have the right to a written statement of the specific reasons for the denial. To obtain the statement please contact Silicon Valley Bank, 3003 Tasman Drive, Santa Clara CA 95054, 800.774.7390 within 60 Days from the date you are notified of our decision. We will send you a written statement of reasons for the denial within 30 days of receiving your request for the statement.",
            verifyNewCardMainContentSecParaHeading: "Equal Credit Opportunity Act Notice",
            verifyNewCardMainContentSecParaText: "The Federal Equal Credit Opportunity Act prohibits creditors from discriminating against credit applicants on the basis of race, color, religion, national origin, sex, martital status, age (provided the applicant has the capacity to enter into a binding contract); because all or part of the applicant's Income derives from any public assistance program; or because the applicant has in good faith exercised any right under the Consumer Credit Protection Act. The federal agency that administers compliance with this law concerning this creditor is the Bureau of Consumer Financial Protection, 1700 G Street NW, Washington DC 20006",
            plasticLabel: "Plastic",
            plasticTolltip: "Plastic will be issued",
            nonPlasticLabel: "Non-Plastic",
            carholderFirstNameLabel: "Cardholder First Name",
            carholderLastNameLabel: "Cardholder Last Name",
            cardHolderNameOnCardLabel: "Cardholder Name on Card",
            maximumCharactersLabel: "Maximum 21 characters",
            optionalPlaceholder: "Optional",
            lastDigitsSSNLabel: "Last 4 Digits of SSN",
            lastDigitsSSNtoolTip: "This information is only used to verify cardholder identity when they call SVB Card Support. If cardholder is not a US Citizen please provide last four digits of Passport Number or another unique identifier.",
            lastDigitsSSNErrorMsg: "Format invalid. Last four digits of SSN must be exactly four digits (e.g. 4321).",
            zipErrorMsg: "ZIP/Postal code required. ZIP/Postal code must be exactly five digits (e.g. 54321).",
            dobmmddLabel: "Date of Birth (MM/DD/YYYY)",
            reqCardholderLimitLabel: "Requested Cardholder Limit",
            emailLabel: "Email",
            emailErrorMeg: "Valid email required.  Please re-enter.",
            cellPhoneLabel: "Cell Phone",
            businessPhoneLabel: "Business Phone",
            cardDeliveryLabel: "Card Delivery",
            standardFreeLabel: "Standard (Free)",
            expeditedamtLabel: "Expedited ($35.00)",
            UsCitizenLabel: "U.S. Citizen",

            addressTitleNewcard: "Do you want the new card shipped to your address on record?",
            addressTitleReplaceCard: "Would you like the replacement card shipped to the address on record?",
            addressOnRecordLabel: "Address on Record",
            selectLabel: "Select",
            anotherAddrsLabel: "Use another address",
            newAddrsLabel: "New Address",
            addressFiledLabel: "Please fill out the fields below.",
            fullNameLabel: "Full Name",
            cityLabel: "City/Town",
            addressOneLabel: "Address 1",
            stateLabel: "State/Province",
            addressTwoLabel: "Address 2",
            zipLabel: "ZIP/Postal Code",
            countryLabel: "Country",
            othersDropdown: "Others",
            townDropdown: "town",

            spendLimitHeader: "Spend Limit",
            pendingApprovalsLabel: "Pending Approvals",
            pendingApprovalLeftLabel: "Maintenance Requests Pending Approval",
            pendingApprovalNoRequest: "There are no maintenance requests pending your approval at this time",
            maintenanceRequestFirstPara: "Modify maintenance requests currently pending approval.",
            maintenanceRequestSecondPara: "Modifications to pending requests require another card account manager's approval.",
            importantText: "Important: ",
            spendLimtChangeTableTitle: "Spend Limit Changes",
            newCardRequestTableTitle: "New Card Requests",
            approvalTableHeaderApproveAll: "Approve All",
            approvalTableHeaderRejectAll: "Reject All",
            approvalTableHeaderNoDecision: "No Decision",
            approvalHeader: "Approval",
            decisionHeader: "Decision",
            statusHeader: "Status",
            limitHeader: "Limit",
            shippingHeader: "Shipping",
            cashAdvanceHeader: "Cash Advance",
            cardFormatHeader: "Card Format",
            cardFormatToolltip: "Virtual accounts that roll up to a single account.",
            applyLimitTemporaryTooltip: "Temporary limit dates are optional. If this field reads Permanent the new limit will take affect immediately. The limit can be changed at any time by selecting Manage Spend from the Overview page.",
            submitForApproval: "Submit for Approval",
            manageCashAdvance: "Manage Cash Advance",
            applyLimitTemp: "Apply Limit Temporarily (Optional)",
            currentLimitHeader: "Current Limit",
            cardholder: "Cardholder",
            accountHash: "Acct #",
            dotDotDot: "...",
            dateFormat: "MMM DD, YYYY",
            enabledHeader: "Enabled",
            disabledHeader: "Disabled",
            contactHyperlink: "http://www.svb.com/contactus.aspx?panel=3",
            pipeline: "|",
            or: "or",
            sorryCardDelete: "sorry, your selected card is not deleted successfully!",
            newLimitHeader: "New Limit",
            initiatorHeader: "Initiator",
            accountTypeLabel: "Account Type",
            newCompanyLimitReqTextPerInc: "New Company Limit Requested",
            currentCompanylimitTextPerInc: "Current Company Limit",
            fyeTextPerInc: "Has the company had a fiscal year end (FYE)?",
            addlInfoPerinc: "Please provide any additional information for this request (optional).",
            dateOfFyeWithFormat: "Date of FYE(MM/YYYY)",
            dateOfFyeWithoutFormat: "Date of FYE",
            totalRevenueTextPerInc: "Total Revenue",
            yearToDateTextPerInc: "Year-to-Date Revenue",
            limitChangePerInc: "Limit Change",

            programTypeElite: "Business Elite",
            programTypeBusiness: "Business",
            activeStatus: "[blank]",
            suspendedStatus: "F",
            closedStatus: "C",
            ICCheck: "IC",
            fromDateId: "fromdate",
            todateId: "todate",
            currentStatus: "Current Status",
            newStatus: "New Status",
            suspendOption: "Suspend Temporarily (Optional)",
            NALabel: "N/A",
            verifyLabel: "Verify Status change",

            statementsLabel: "Statements",
            downloadsLabel: "Downloads",
            titleLabelStatements: "Downloads Statements",
            mailingAddressLabel: "Current Mailing Address",
            downloadButton: "Download",

            tooltipTitle: "Temporary Spend Limit",
            titledownloadsLabel: "Downloads for:",
            statementMailingAddressTooltipLabel: "The current address on file for your company, or for selected cardholder, is listed below. Paper statements (optional) are delivered to this address.",
            selectCardholderLabel: "Select cardholders",
            viewCardholderLabel: "View/Select cardholders",
            dateRangeTooltipForDownloads: "Activity for the past 13 months is available to download. Enter the desired date range or select the Statements tab above to download specific statements.",
            downloadsFileFormatLabel: "File Format",
            addMoreCardholdersLabel: "Add More Cardholders",
            downloadsInstructionHeaderLabel: "Select one of the following options:",
            downloadsInstructionLabel1: "Select your company account to download all account activity for all cards for the selected time period.",
            downloadsInstructionLabel2: "Select one of more individual cardholders from the list below to download account activity for only those individuals for the selected time period.",
            reportLinkLabel: "Report Lost or Stolen",
            replacementLink: "Request Replacement Card",
            iWantLabel: "I want to...",
            stolenLink: "Report a card lost or stolen",
            freezeLink: "Freeze a card temporarily",
            assistance: "For immediate assistance:",
            tollFreeLabel: " (toll free)",
            internationalLabel: " (international)",
            localLabel: " (local)",
            contactMessage: "24 hours a day, 7 days a week",
            trusteeText: "Trusteer Rapport®",
            trusteeAddText: "Get an added layer of online security",
            fraudText: "Fraud Prevention",
            fraudLabelText: "SVB Fraud Prevention Center",
            stolenHeader: "Report a Card Lost or Stolen",
            validateHeader: "Validate Recent Activity",
            freezeHeader: "Freeze a Card Temporarily",
            cardholderNameLabel: "Cardholder Name",
            cardNumberDigitLabel: "Card Number (last 4 digits)",
            requestFailedLabel: "Request Failed",
            freezeLabelOne: "By selecting ",
            freezeLabelOneEnd: " you are authorizing SVB to place this card in a suspended status.",
            freezeLabelTwo: "This card will not be eligible for use until Reactivated.",
            freezeLabelThree: "To reactivate this card, please select ",
            freezeLabelThreeEnd: " from the Overview page.",
            freezeConfirmScreenLabel: "The card has been suspended until further notice. To reactivate this card, please select Change Status from the Overview page. This card will now be listed within the Suspended Cards group.",
            freezeFailureText: "We apologize, but at this time we are unable to process your request online.",
            freezeFailedLabel: "Please call us to complete this request.",
            reportValidateLabel: "Below is a list of all account activity for this card for the last 30 days.",
            validateBoldLabel: " Review all activity carefully and flag any items you suspect as fraudulent",
            validateLableTwo: "Once you have completed a review of the below activity, click the Next button at the bottom of the screen to complete the shipping details for your replacement card.",
            reportLostPossession: "Is the card still in cardholder possession?",
            repotLostStateLabel: "If No, please select the state where the card was lost or stolen.",
            lostKnownCountryLabel: "Please enter the country or last known location.",
            shippingLabelOne: " Last step! Confirm that we should send the new card to the address on record below or provide an alternate address to send the new card to.",
            shippingFreeLabel: "We'll expedite the delivery of your new card free of charge.",
            shippingLabelTwo: "We also ask that you provide a brief summary or additional details regarding the loss or theft of your card in the space below.",
            shippingLabel: "How would you like this card delivered?",
            expeditedLabel: "Expedited delivery (2 business days)",
            standardLabel: "Standard delivery (7-10 business days)",
            chargeLabel: "No charge",
            briedValueLabel: "Please provide a brief summary or additional details regarding the loss or theft of your card.",
            damageCardLink: "Replace a damaged card",
            neverReceivedLink: "Report a card never received",
            changeNameLink: "Change a name on a card",
            damageCardLabelOne: "If a card is damaged we can send the cardholder a replacement card.",
            damageCardLabelTwo: "Please keep in mind:",
            damageCardLabelThree: "-The new card will have the same card number as the old card.",
            damageCardLabelFour: "-The expiration date will change and recurring charges will need to be updated by cardholder.",
            notReceivedLabelOne: "If the above card was originally shipped expedited please",
            notReceivedLabelTwo: " call us directly ",
            notReceivedAssistanceLabel: "for assistance.",
            notReceivedLabelThree: "Otherwise, provide the below information.",
            notReceivedLabelfour: "When did you order the card?",
            stolenDateLabel: "Date",
            changeNameLabelOne: "Updated Name on Card",
            maxCharacterLabel: "Max 21 characters",
            changeNameshippingLabel: "When would you like to receive this card?",
            changeNameLabelTwo: "Please provide proof of your name change by attaching a scanned copy of an acceptable form of verification. Examples of acceptable forms of ID are provided below.",
            drivingProofLabel: "Driver's License",
            militaryProofLabel: "Military ID Card",
            stateIdLabel: "State Issued ID Card",
            marriageLabel: "Marriage Certificate",
            passportLabel: "Passport",
            divorceLabel: "Divorce Decree",
            residentLabel: "Permanent Resident Card",
            natureLabel: "Certificate of Naturalization",
            courtOrderLabel: "Court Order for Name Change",
            pluginErrortext: "Please install flash plugin or update your browser.",
            lostQuestionLabel: "Where was the card lost?",
            reportVerifyLabelOne: "The new card is on the way. Keep in mind:",
            reportVerifyLabelTwo: "1. Recurring charges will need to be updated by cardholder.",
            reportVerifyLabelThree: "2. The balance, recent payments and rewards (if applicable) will be transferred to the new card.",
            reportVerifyLabelFour: "3. SVB will dispute any charges marked as suspicious on your behalf. We will mail a letter to the cardholder with a status of the dispute(s) within 7-10 business days.",
            reportVerifyLabelFive: "4. If the old card has been registered on online banking, the new card can be registered under the cardholder's current online banking user ID as well. To register the new card, cardholders can log in to online banking with their current ID, go to the preferences section and select ",
            reportVerifyLabelSix: "Register another card.",
            nameVerifyLabelOne: "- Recurring transactions will need to be established on your new card.",
            nameVerifyLabelTwo: "- Your balance will be transferred to your new card.",
            nameConfirmationText: "Your name change has been submitted. A member of our Card Service team will contact you within one business day if any additional information is needed to apply this name change.",
            newCardConfirmLabel: "The new card is on the way.",
            damageVerifyLabelOne: "Verify the delivery information below.",
            damageVerifyLabelTwo: "We'll expedite the delivery of your new card free of charge.",
            receivedVerifyLabel: "We are expediting the delivery of your new card, free of charge, to the address below.",
            stolenFailureText: "We apologize, but at this time we are unable to process your request online. A member of our Card Support team will contact you within 24 business hours to assist with completing your request.",
            shippedToLabel: "Card will be shipped to:",
            expectedLabel: "Expected Delivery Date:",
            stolenConfiramLabelOne: "Please feel free to contact our Card Support team at",
            stolenLabelConfirm: " with questions. SVB will communicate on any needed additional steps through resolution.",
            receivedFailureText: "We apologize, but we are unable to process your request online at this time.",
            PleaseLabel: "Please",
            callUsLabel: " call us ",
            changeNameShipingMsg: "Please confirm that we should send the replacement card to the address on record below or provide an alternate address to send the replacement card to.",
            pleaseCallAtText: " to complete this request.",
            nameOnCard: "Name on Card",
            ssnLabel: "Social Security Number",
            dobLabel: "Date of Birth",
            usCitizenLabel: "US Citizen",
            employeeIdLabel: "Employee ID",
            shippingAddressLabel: "Shipping Address",
            nonPLasticTooltipMsg: "For non-plastic cards a member of SVB Card Support will call the requester directly with the new card details. Please allow three business days for new card details to be provided.",
            deleteSpendLimitFromQueue: "Do you really want to cancel this pending request to change this cardholder's spend limit?",

            deleteCashAdvanceFromQueue: "Do you really want to cancel this pending request to change this cardholder's cash advance setting?",
            paymentForLabel: "Payment for",
            fromAccountLabel: "From Account",
            autoPaymentToLabel: "Payment To",
            warningAlertPaymentAcct1: "Are you sure you want to delete Payment Account ...",
            warningAlertPaymentAcct2: "Important: Any scheduled payments associated with this Payment Account will be deleted and will not be processed.",
            balanceLabel: "BALANCE",            
            dobErrorMsg: "Must be 18 years or older"
           
        },

        urls: {
            contactServiceUrl: "http://www.svb.com/contactus.aspx?panel=3",
            privacyPolicy: "http://www.svb.com/Privacy-Policy/",
            rewardUrl: "https://www.svbglobalrewards.com/svbglobalrewards/rewards/SignInServlet?bank_id=102041103&i18n=en_US",
            masterCardUrl: "https://www.mastercardeasysavings.com/ezsavings/ControllerServlet?bank_id=186069&i18n=en_US",
            smartDataUrl: "https://smartdata.svb.com/sdportal/home.view"

        },

		authentify: {
            "newcard": {
                "urlId": "110",
                "urlName": "/ca/ui/app/Newcard/newcard.html"
            },

            "manageSpend": {
                "urlId": "109",
                "urlName": "ca/ui/app/Managespend/manageSpend.html"
            },
            "shippingAddress": {
                "urlId": "108",
                "urlName": "/ca/ui/widgets/ccShippingAdddress/ccShippingAddress.html"
            }
        },

        monthArray: [31, [28,29], 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],

        paymentHistoryChunkCount: 500,

        sortData: function(data, prop) {
            var len = data.length;
            for (var i = len - 1; i >= 0; i--) {
                for (var j = 1; j <= i; j++) {
                    if (data[j - 1][prop] > data[j][prop]) {
                        var temp = data[j - 1];
                        data[j - 1] = data[j];
                        data[j] = temp;
                    }
                }
            }

            return data;
        },

        showWarningAlert: function(selectedProgram) {
            var len = util.showWarningMessages.length;

            for (var i = 0; i < len; i += 1) {
                var programItem = util.displayWarningMessages[i];

                if (String(programItem.program) === String(selectedProgram)) {
                    if (programItem.showWarningMessage) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        },

        setWarningAlert: function(value) {
            var len = util.showWarningMessages.length;

            for (var i = 0; i < len; i += 1) {
                var programItem = util.displayWarningMessages[i];

                if (String(programItem.program) === String(util.currentProgramId)) {
                    programItem.showWarningMessage = value;
                }
            }
        },

        getCardData: function(encAccountNumber) {
            var len = util.allProgramAccounts.length;

            for (var i = 0; i < len; i += 1) {
                var accountItem = util.allProgramAccounts[i];

                if (String(accountItem.account.encAccntNumber) === String(encAccountNumber)) {
                    accountItem.account.ceid = util.ceid;
                    return accountItem;
                }
            }
        },

        getCardAccountDetailData: function(encAccountNumber) {
            var len = util.allCardAccountDetails.length;

            for (var i = 0; i < len; i += 1) {
                var accountItem = util.allCardAccountDetails[i];

                if (String(accountItem.encAccntNumber) === String(encAccountNumber)) {
                    return accountItem;
                }
            }
        },

        allowAlphaNumeric: function(element, event) {
            try {
                var charCode;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === "object") {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if ((charCode > 64 && charCode < 91) || (charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 46) {
                    return true;
                }

                return false;
            } catch (err) {
                new Error(err.Description);
            }
        },
        allowAlphaNumericSpace: function(element, event) {
            try {
                var charCode;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === "object") {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if ((charCode > 64 && charCode < 91) || (charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 32 || charCode === 46) {
                    return true;
                }

                return false;
            } catch (err) {
                new Error(err.Description);
            }
        },

        aplhanumericHyphen: function() {
            var alphanumeric = /[#,A-Za-z0-9 ]/;
            var keyChar = String.fromCharCode(event.which || event.keyCode);
            return alphanumeric.test(keyChar) ? true : false;
        },

        doNothing: function() {
            //console.log('right click disabled');
        },
        allowNumeric: function(element, event) {
            try {
                var charCode;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === "object") {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if ((charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 46) {
                    return true;
                }

                return false;
            } catch (err) {
                new Error(err.Description);
            }



        },

        closePaymentModal: function() {
            $('.ca-payment').remove();

            if ($('[data-svb-cc-module="paymentactivity"]').hasClass('svb-active')) {
                $('.ca-content').remove();

                require(["navigation", "mockConfig"], function(navigation) {
                    navigation("paymentactivity");
                });
            } else if ($('[data-svb-cc-module="cardholder"]').hasClass('svb-active')) {
                $('.ca-content').remove();

                require(["navigation", "mockConfig"], function(navigation) {
                    navigation("cardholder");
                });
            } else if ($('[data-svb-cc-module="overviewCa"]').hasClass('svb-active')) {
                $('.ca-content').remove();

                require(["navigation", "mockConfig"], function(navigation) {
                    navigation("overviewCa");
                });
            } else {
                $('.ca-content').removeClass('ca-modal-outer-container');
                $('.ca-content').show();
            }
        },

        // added by vinoth to check for valid dates
        checkDate : function (selectDate) {
            var selectedDate = "";
            var serverDate = "";
            var date = "";
            var month = "";
            var year = "";

            month = selectDate.substring(0, 2);
            date = selectDate.substring(3, 5);
            year = selectDate.substring(6, 10);
            selectedDate = new Date(year, month - 1, date);
            serverDate = new Date(util.serverDate);
            serverDate = (serverDate.getMonth() + 1) + "/" + serverDate.getDate() +  "/" + serverDate.getFullYear();
            serverDate = new Date(serverDate);

            if ((selectedDate > serverDate) || (selectedDate.getTime() === serverDate.getTime())) {
                return true;
            } else {
                return false;
            }
        }

    };
    return util;
});