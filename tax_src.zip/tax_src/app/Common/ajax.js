/* jshint browser: true */
define(["jquery","util"], function ($,util) {
    var ajaxCall = {
        getJSON: function (url, type, data, successCallback, errorCallback) {
            if (type === undefined || type === "") {
                type = "get";
            }
            if (data === undefined) {
                data = "";
            }

            data = JSON.stringify(data);

            $.ajax({
                url: url,
                type: type,
                data: data,
                dataType: 'json',
                contentType: "application/json;charset=UTF-8",
                headers: {
                    "X-Requested-By": util.requestedBy
                },
                success: function (responseData,sts,xhr) {
                    var sessionMessageCode;

                    if (util.isProduction) {
                        util.serverDate = xhr.getResponseHeader("serverDatePST");
                        
                        util.requestedBy = (xhr.getResponseHeader("X-Requested-By")) ? xhr.getResponseHeader("X-Requested-By") : util.requestedBy;
                    } else {
                        util.serverDate = new Date();
                    }

                    $.serverDate = util.serverDate;

                    if(responseData) {
                        if(responseData.data) {
                            if (responseData.data.hasOwnProperty("result")) {
                                sessionMessageCode = responseData.data.result.messageCode;
                                if (sessionMessageCode === "100") {
                                    window.location.pathname = '/auth/';
                                    return;
                                }
                            }
                        }
                        if (typeof successCallback === "function") {
                            successCallback(responseData);
                        }

                    }
                },
                error: function (responseData,sts,xhr) {
                    if (typeof errorCallback === "function") {
                        errorCallback();
                    }
                }
            }).done(function () {

            });
        },

        getCompanyView: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/account/getCompanyView":"/getDonutData";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getProgramNotification: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/getWorkflowNotification":"/getNotification";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getTableData: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/account/getCompanyAccountView":"/getCompanyViewAccount";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getControlCardDetail: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/account/getAccountDetails":"/getControlAccount";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getStatementDatesRange: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/transaction/getStatementDatesRange":"/getStatementDates";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getControlCardAccountData: function (req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/account/getAccountDetailsWithAuth" : "/getControlCardData";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getAuthTransData: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/transaction/getAuthorization":"/getAuthTransactions";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getPostTransData: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/transaction/getPostedTransaction":"/getPostTransactions";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        
        registerCardHolderActivityAudit: function (req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/audit/performCardholderAudit" : "/getPerformAuditReport";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getStatementsList: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/transaction/getStatementDates":"/getStatementsList";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getChangeStatusData: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/changeStatus":"/getChangeStatusResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        checkPayAccUsed: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/checkPayAccUsed":"/checkPayAccUsed";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        deletePaymentAccount: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/delete":"/deletePaymentAccount";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        makePayment: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/create":"/makePayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        deletePayment: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/cancel":"/deletePayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        updatePayment: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/edit":"/makePayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        initPayment: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/init":"/initPayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        reviewPayment: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/review":"/reviewPayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        addPaymentAccountService: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/create":"/addPaymentAccountService";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        updatePaymentAccountService: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/edit":"/addPaymentAccountService";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getPaymentAccounts: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/getPaymentAccounts":"/getPaymentAccounts";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getSearchBankRoutingDetails: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/paymentAccount/getBankDetails":"/getSearchBankRoutingDetails";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        scheduledPayments: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/getSchPayments":"/scheduledPayments";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        paymentHistory: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/payment/getPaymentHistory":"/paymentHistory";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        
        registerPaymentActivityAudit: function (req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/audit/performPaymentHistoryAudit" : "/getPerformAuditReport";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        approvePendingPayment: function (req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/payment/workflowAction": "/getPendingApprovalPayment";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        newCardRegistration: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/newCardRequest":"/newCardRegristration";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        permanantIncreaseReq: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/companyLimitChange":"/permanantIncreaseReq";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        // request for changelimit
        getChangeLimitData: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/updateSpendLimit":"/getSpendLimitResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        // request for cashAdvance
        getCashAdvanceData: function (req,callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/updateCashAdvance":"/getCashAdvanceResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getPendingMaintenanceRequest: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/getPendingMaintenance":"/getPendingMaintenanceRequest";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        getPendingApprovals: function (req,callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/getPendingApprovals":"/getPendingApproval";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        updateEditCardResponse: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/editNewCardRequest":"/updateEditCardResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        //Edit Manage Spend response for workflow
        getWorkflowEditManageSpendResponse: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/editSpendLimit":"/workflowManageSpendEditResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        //Edit cash advance response for workflow
        getWorkflowEditCashAdvanceResponse: function(req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/editCashAdvance":"/workflowCashAdvanceEditResponse";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        reviewPendingApproval: function(req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/reviewWorkflow":"/getReviewPendingApproval";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        confirmPendingApproval: function(req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/takeAction":"/confirmPendingApproval";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        sendPaymentReminder: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/workflow/paymentReminder":"/getNotification";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        //Edit Manage Spend response for workflow
        getWorkflowEditManageSpendResponseSingleCard: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/cancelSpendLimitRequest":"/workflowManageSpendEditResponseSingleCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },

        //Edit cash advance response for workflow
        getWorkflowEditCashAdvanceResponseSingleCard: function(req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/cancelCashAdvRequest":"/workflowCashAdvanceEditResponseSingleCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        cancelCardRequest:  function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/cancelNewCardRequest":"/cancelCardRequest";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        freezeCard:  function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/repostLs":"/freezeCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getHolidaysList: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/cancelNewCardRequest":"/getHolidaysList";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getDamageCard: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/repostLs":"/freezeCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getChangeNameOnCard: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/repostLs":"/freezeCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getCardNvrCreated: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/repostLs":"/freezeCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getLostStolenResponse: function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/repostLs":"/freezeCard";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        disputeEmailSend:  function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/disputeAction/disputeEmailReq":"/disputeEmailSend";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        getSpendLimitDetails:  function (req, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/initManageSpend":"/initManageSpend";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        overrideNewStatusRequest: function (request, callback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/initChangeStatus":'/overrideNewStatusRequest';
            ajaxCall.getJSON(urlMap, "POST", request, callback);

        },
        overviewAuditEvent: function (req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/audit/performOverviewAudit" : "/getPerformAuditReport";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        searchAuditEvent: function(req, callback) {
            var urlMap = (util.isProduction) ? "/ca/service/api/audit/performOverviewAudit" : "/getPerformAuditReport";
            ajaxCall.getJSON(urlMap, "POST", req, callback);
        },
        changeNameOnCard: function (req, successCallback) {
            var urlMap = (util.isProduction)?"/ca/service/api/cardsAction/changeNameOnCard":"/freezeCard";
            $.ajax({
                url: urlMap,
                data: req,
               /* cache: false,*/
                contentType: false,
                async: false,
                /*dataType:"multipart/form-data",*/
                processData: false,
                type: 'POST',
                success: function (data) {
                    if (typeof successCallback === "function") {
                        successCallback(data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown){
 
                }
            });
        }

    };
    return ajaxCall;
});

