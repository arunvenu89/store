/* jshint browser: true */
define(["knockout", "jquery", "html!stolenTpl", "ajaxCall", "util", "file-bindings", "FileAPI", "widgetRegistry", "css!caStyles"], function(ko, $, Reporttpl, AJAX, util, file, FileAPI) {
    function ReportStolenCard(params) {
        var self = this;

        self.verbiage = util.verbiage;
        self.urls = util.urls;

        self.elementPresent = $('.ca-content').hasClass('ca-stolencard');
        if (!self.elementPresent) {
            $('.svb-cardsAdmin').append(Reporttpl);
        } else {
            return;
        }

        $('html, body').animate({
            scrollTop: 0
        }, 'slow', function() {
            $('.ca-stolencard').animate({
                top: 0
            }, 'slow');
            $('.' + params.initModule).slideUp('slow');

        });


        self.checkResult = false;
        self.totalFileSize = 0;
        self.emptyTitle = ko.observable(true);
        $('.ca-stolenCard-footer-container').hide();

        self.cardholderCountry = ko.observable();
        self.showAttachErrorMsg = ko.observable(false);
        self.cardHolderText = ko.observable();
        self.contactServiceMsg = self.verbiage.contactServiceInstructionLabel + "<a href='" + self.urls.contactServiceUrl + "' target='_blank'>" + self.verbiage.clientSupportLabel + "</a>.";
        self.serverFail = ko.observable(false);
        self.shippingObs = ko.observable(false);
        self.showFreeText = ko.observable();
        self.disableResult = ko.observable();
        self.isControlCard = false;
        self.disableRequest = ko.observable(false);
        self.selectedOption = ko.observable();
        self.showState = ko.observable();
        self.othersCountry = ko.observable(false);
        self.selectDate = ko.observable();
        self.minDate = ko.observable();
        self.disableAttachBtn = ko.observable(false);
        self.maxDate = ko.observable(new Date(util.serverDate));
        self.nextScreen = ko.observable((util.nextScreen) ? util.nextScreen : '');
        self.showTab = ko.observable('');
        self.replaceCardTitle = ko.observable();
        self.isEliteCard = false;
        self.isVerify = ko.observable(false);
        self.isCancelClicked = ko.observable(true);
        self.fileName = ko.observableArray();
        self.showFileName = ko.observable(false);
        self.updatedName = ko.observable();
        self.dropdowndefault = ko.observable();
        self.selectDefault = ko.observable(0);
        self.selectDefaultCountry = ko.observable(0);
        self.showTransTable = ko.observable(false);
        self.showButtons = ko.observable(false);
        self.selectedCard = params.cardSelected;
        self.widgetAddress = ko.observable();
        self.stolenCountry = ko.observable();
        self.expectedDays = ko.observable();
        self.briefDesc = ko.observable();
        self.isNewAddress = ko.observable(false);
        self.fileArray = [];
        self.isDispute = (params.fromDispute) ? 'Dispute' : 'Verify';
        self.isFromCardHoder = params.navigationFromCardHolder;
        self.binaryfile = ko.observableArray();
        self.showScreen = (util.showScreen) ? ko.observable(util.showScreen) : ko.observable();
        self.showSuccess = ko.observable(false);
        self.showFailure = ko.observable(false);
        self.todayDate = new Date(util.serverDate);
        self.disableNxtBtn = ko.observable(true);
        self.uploadedFile = ko.observableArray();

        self.isElite = ko.observable(false);
        util.selectedAuth = [];
        util.selectedPost = [];
        self.showExpedited = ko.observable(true);
        self.addLine1 = ko.observable();
        self.addLine2 = ko.observable();
        self.city = ko.observable();
        self.postalCode = ko.observable();
        self.showAddWidget = ko.observable(false);
        self.isBorderNone = ko.observable(false);
        self.stateCode = ko.observable();
        self.loaderStatus = ko.observable();
        self.loaderModule = ko.observable('ca-stolencard');
        self.loaderDetail = ko.pureComputed(function() {
            var detail = {};
            detail.status = self.loaderStatus();
            detail.module = self.loaderModule();
            return detail;
        });
        self.loaderStatus(false);
        self.loaderModule('ca-stolencard');
        self.hitCount = 0;

        var date = new Date(util.serverDate);
        date.setDate(date.getDate() - 10);
        var today = date.getDate();
        var month = date.getMonth() + 1;
        var year = date.getFullYear();
        var finalDate = new Date(month + '/' + today + '/' + year);
        self.maxDate(finalDate);
        self.newDate = new Date(util.serverDate);
        self.toDate = (self.newDate.getMonth() + 1) + '/' + self.newDate.getDate() + '/' + self.newDate.getFullYear();
        self.newDate.setDate(self.newDate.getDate() - 31);
        self.fromDate = (self.newDate.getMonth() + 1) + '/' + self.newDate.getDate() + '/' + self.newDate.getFullYear();

        self.getToDate = function(givenDate) {
            var currentDate = new Date(util.serverDate);
            var splittedDate = givenDate.split('/');

            currentDate.setFullYear(splittedDate[2]);

            currentDate.setMonth(11);
            currentDate.setDate(31);

            currentDate.setDate(splittedDate[1]);
            currentDate.setMonth(splittedDate[0]);

            currentDate.setDate(currentDate.getDate() - 31);
            return (currentDate.getMonth() + '/' + currentDate.getDate() + '/' + currentDate.getFullYear());
        };

        self.fileData = ko.observable({
            file: ko.observable() // will be filled with a File object		
        });

        self.fileData().file.subscribe(function(val) {
            self.count = self.count + 1;
            self.checkResult = false;
            self.showFileName(true);
            var fileSzie = self.fileData().file().size / 1024000;
            if (self.totalFileSize !== 0) {
                self.totalFileSize = self.totalFileSize + fileSzie;
            }
            if (((self.totalFileSize === 0 && fileSzie < 11) || (self.totalFileSize !== 0 && self.totalFileSize < 11)) && (self.fileData().file().name.substr(self.fileData().file().name.lastIndexOf('.')) !== '.exe')) {
                ko.utils.arrayFirst(self.fileName(), function(name) {
                    self.checkResult = (self.fileData().file().name === name.fname);
                    return self.checkResult;
                });
                if (!self.checkResult) {
                    if (self.totalFileSize === 0) {
                        self.totalFileSize = self.totalFileSize + fileSzie;
                    }
                    self.fileName.push({
                        'fname': self.fileData().file().name,
                        'size': self.fileData().file().size / 1024000
                    });
                    self.fileArray.push(self.fileData().file());
                    self.getUploadFileRequest();
                    self.enableNxtBtn();
                    if (self.fileName().length === ((document.addEventListener && !window.requestAnimationFrame) /* ie detection hack */ ? 1 : 5)) {
                        self.disableAttachBtn(true);
                        $('#fileUpload')[0].disabled = 'disabled'; //using jQuery binding as in IE9 case binding FileBinding is not available
                    }
                }
            } else if (self.totalFileSize !== 0) {
                self.totalFileSize = self.totalFileSize - fileSzie;
            }
            $('#fileUpload').val('');
        });

        self.flashFileUpload = function(m, e) {
            var files = FileAPI.getFiles(e);
            self.fileData().file(files[0]);
            //this will manually call subscribe for ie9
        };
        self.removeUploadedFile = function(index) {
            var items = self.binaryfile();
            items.splice(index(), 1);
            self.binaryfile(items);

            var nameItem = self.fileName();
            self.totalFileSize = self.totalFileSize - (nameItem[index()].size);
            nameItem.splice(index(), 1);
            self.fileName(nameItem);

            var fileItem = self.fileArray;
            fileItem.splice(index(), 1);
            self.fileArray = fileItem;
            self.disableAttachBtn(false);
            $('#fileUpload')[0].disabled = false; //using jQuery binding as in IE9 case binding FileBinding is not available            
            self.enableNxtBtn();
        };

        self.switchTab = function(element, event) {
            var activeElement = $(event.currentTarget).hasClass('selected'),
                activeContainer = $(event.currentTarget.parentElement.parentElement.parentElement).find('.active-container'),
                inactiveContainer = $(event.currentTarget.parentElement.parentElement.parentElement).find('.inactive-container'),
                selectedElem = $(event.currentTarget.parentElement).find('.selected'),
                notSelectedElem = $(event.currentTarget.parentElement).find('.not-selected');

            if (!activeElement) {
                selectedElem.removeClass('selected').addClass('not-selected');
                notSelectedElem.removeClass('not-selected').addClass('selected');
                activeContainer.removeClass('active-container').addClass('inactive').addClass('inactive-container');
                inactiveContainer.removeClass('inactive-container').removeClass('inactive').addClass('active-container');
            }
        };

        self.getAccountDetails = function() {
            for (var i = 0; i < util.entitledPrograms.length; i++) {
                if (util.selectedProgram.id === util.entitledPrograms[i].program.companyId) {
                    if (util.entitledPrograms[i].program.hasOwnProperty('subAccount') && util.entitledPrograms[i].program.hasOwnProperty('controlCard')) {
                        util.selectedEntitledProgram = util.entitledPrograms[i].program;
                        self.cachedProgram = util.entitledPrograms[i];

                        self.controlCard = util.entitledPrograms[i].program.controlCard;
                        self.subAccounts = util.entitledPrograms[i].program.subAccount;

                        self.selectedProgramAddress = util.entitledPrograms[i].program.controlCard.account.accountHolder;
                        var programStatus = util.entitledPrograms[i].program.controlCard.account.status;

                        if (util.entitledPrograms[i].program.controlCard.account.encAccntNumber === self.selectedCard) {
                            /*need to change*/
                            self.isControlCard = false;
                            self.cardHolderName = self.selectedProgramAddress.firstName + ' ' + self.selectedProgramAddress.lastName;
                            self.lastFourDigit = '....' + self.controlCard.account.lastFourDigit;
                            self.encAccntId = self.controlCard.account.encAccntNumber;
                        }
                        self.entitledProgramIndex = i;
                        var prin = util.entitledPrograms[i].program.prin;
                        if (prin === '2000') {
                            self.isElite(true);
                            $.showErrorEliteMessage = true;
                            self.isEliteCard = true;
                            self.tollFree = '1-866-940-5920';
                            self.international = ' 408-654-7720';
                        } else {
                            self.tollFree = ' 1-866-553-3481';
                            self.international = ' 001-781-756-8155';
                            $.showErrorNonEliteMessage = true;
                        }
                        break;
                    }
                }
            }
            if (params.cardDetailData === undefined) {
                for (var j = 0; j < self.subAccounts.length; j++) {
                    if (typeof self.selectedCard !== 'string') {
                        self.currentCard = self.selectedCard()[0];
                    } else {
                        self.currentCard = self.selectedCard;
                    }

                    if (self.subAccounts[j].account.encAccntNumber === self.currentCard) {
                        self.selectedSubAccounts = self.subAccounts[j];
                        self.subAccountsIndex = j;
                        self.cardHolderName = self.selectedSubAccounts.account.cardHolderName;
                        self.lastFourDigit = '....' + self.selectedSubAccounts.account.lastFourDigit;
                        self.encAccntId = self.selectedSubAccounts.account.encAccntNumber;
                        break;
                    }
                }
            } else {
                var accountData = params.cardDetailData.accountHolder;
                self.cardHolderName = (accountData.middleName !== undefined) ? (accountData.firstName + ' ' + accountData.middleName + ' ' + accountData.lastName) : (accountData.firstName + ' ' + accountData.lastName);
                self.lastFourDigit = '....' + params.cardDetailData.lastFourDigit;
            }
        };
        self.redirectToRapport = function() {
            window.open('http://www.svb.com/fraud-prevention/trusteer/');
        };
        self.redirectToFraud = function() {
            window.open('http://www.svb.com/fraud-prevention');
        };

        self.closeModel = function() {

            $('.ca-stolencard').animate({
                top: 1200
            }, 'slow');
            $('.' + params.initModule).slideDown('slow');
            $('.ca-stolencard').remove();
            $.showErrorEliteMessage = false;
            $.showErrorNonEliteMessage = false;
            if ($('.ca-content').hasClass('ca-stolenCard-verify')) {
                $('.ca-content').removeClass('ca-stolenCard-verify');
            }

            var param = {};

            if (typeof self.selectedCard !== 'string') {

                param.initModule = 'ca-overview';

                require(['navigation', 'mockConfig'], function(navigation) {
                    var nav = navigation("overviewCa", param);
                });

            } else {
                delete self.controlCard;
                delete self.subAccounts;
                param.initModule = 'ca-card-holder';
                require(['navigation', 'mockConfig'], function(navigation) {
                    var nav = navigation('cardholder', param);
                });

            }
        };
        self.reportCountryList = ko.observableArray();
        var reportTempCountryList = [{
            id: '1',
            value: 'Select'
        }];

        ko.utils.arrayForEach(util.miscInfo.stateList, function(country, index) {
            if (index > 0 && index !== country.length - 1) {
                reportTempCountryList.push({
                    id: country.code,
                    value: country.name
                });
            }
        });
        reportTempCountryList.push({
            id: reportTempCountryList.length - 1,
            value: 'Other'
        });
        self.reportCountryList(reportTempCountryList);
        self.doNothing = function() {};
        self.allowAlphaNumericSpace = function(element, event) {
            util.allowAlphaNumericSpace(element, event);
        };
        self.authTransReq = function() {
            var data = {
                ceid: self.ceid
            };

            return data;
        };
        self.postTransReq = function() {
            self.beginSeqVal = (self.hitCount * 500) + 1;
            self.endSeqVal = self.beginSeqVal + 499;

            var data = {
                ceid: self.ceid,
                period: {
                    fromDate: self.fromDate,
                    toDate: self.toDate
                },
                misc: {
                    beginSeq: self.beginSeqVal,
                    endSeq: self.endSeqVal
                }
            };

            return data;
        };
        self.authTransactionResponse = ko.observableArray();
        self.postTransactionResponse = ko.observableArray();
        self.totalPostTransResponse = ko.observableArray();

        self.doSort = function(collection, prop, asc) {
            var data = util.sortData(collection, prop);

            if (!asc) {
                data = data.reverse();
            }

            return data;
        };

        self.getAuthTransactionsRes = function(data) {
            if (data.data && data.data.result && data.data.result.messageCode && data.data.result.messageCode !== '0') {
                self.serverFail(true);
                self.loaderStatus(false);

            } else {
                var authTransactions = [];

                if (data.data[0].accountDetails.transactions) {
                    authTransactions = data.data[0].accountDetails.transactions;
                }
                ko.utils.arrayForEach(authTransactions, function(item, index) {
                    item.arrayIndex = index;
                });
                util.authTrans = authTransactions;
                util.showData = false;

                self.authTransactionResponse(authTransactions);
            }
        };

        self.getPostTransactionsRes = function(data) {
            if (data.data && data.data.result && data.data.result.messageCode && data.data.result.messageCode !== '0') {
                self.serverFail(true);
                self.loaderStatus(false);

            } else {

                var postTransactions = [],
                    hasmoreData = (data.data[0].accountDetails.isTransactionSeqReq.toUpperCase() === 'TRUE') ? true : false;

                if (data.data[0].accountDetails.transactions) {
                    postTransactions = data.data[0].accountDetails.transactions;
                }
                util.showData = true;
                ko.utils.arrayForEach(postTransactions, function(item, index) {
                    item.arrayIndex = index;
                });
                util.postTrans = postTransactions;
                self.postTransactionResponse(postTransactions);
                if (hasmoreData) {
                    self.hitCount += 1;
                    self.postTransactionsReqData = self.postTransReq();
                    self.loaderStatus(true);
                    AJAX.getPostTransData(self.postTransactionsReqData, self.addPostTransactionsRes);
                    self.loaderStatus(false);
                }
                self.loaderStatus(false);
            }
        };

        self.addPostTransactionsRes = function(data) {
            if (data.data && data.data.result && data.data.result.messageCode && data.data.result.messageCode !== '0') {
                self.serverFail(true);
                self.loaderStatus(false);

            } else {
                var postTransactions = data.data[0].accountDetails.transactions,
                    hasmoreData = (postTransactions.length < 50) ? false : true;

                self.totalPostedTransactions.push.apply(self.totalPostedTransactions, postTransactions);

                if (hasmoreData && (self.hitCount < 2)) {
                    self.hitCount += 1;
                    self.loaderStatus(true);
                    self.postTransactionsReqData = self.postTransReq();
                    AJAX.getPostTransData(self.postTransactionsReqData, self.addPostTransactionsRes);
                } else {
                    self.totalPostTransResponse(self.totalPostedTransactions);
                }
                self.loaderStatus(false);
            }
        };

        util.pageView = 1;
        util.footerView = 1;

        self.getCardHolderCeid = function() {
            self.getCardHolderCeidReq = {
                'data': {
                    'account': [{
                        'accNumber': self.encAccntId
                    }]
                }
            };

            self.getStatus = function(status) {
                if (status === 'F') {
                    self.currentStatusRS = 'Suspended';
                } else {
                    self.currentStatusRS = 'Active';
                }
            };
            self.getCardHolderCeidRes = function(response) {
                if (response.data && response.data.result && response.data.result.messageCode && response.data.result.messageCode !== '0') {
                    self.serverFail(true);
                    self.loaderStatus(false);

                } else {
                    self.ceid = response.data.accountDetails[0].account.ceid;
                    self.tempCurrentStatus = response.data.accountDetails[0].account.status;
                    self.getStatus(self.tempCurrentStatus);
                    self.cardholderAddress = response.data.accountDetails[0].account.accountHolder.address;
                    self.addLine1(self.cardholderAddress.line1);
                    self.addLine2(self.cardholderAddress.line2);
                    self.city(self.cardholderAddress.city);
                    self.postalCode(self.cardholderAddress.postalCode);
                    self.stateCode(self.cardholderAddress.stateCode);
                    self.cardholderCountry((self.cardholderAddress.country !== undefined) ? self.cardholderAddress.country : 'United States');
                    self.cardholderAddress.country = self.cardholderCountry();
                    self.fullName = (response.data.accountDetails[0].account.accountHolder.middleName !== undefined) ? (response.data.accountDetails[0].account.accountHolder.firstName + ' ' + response.data.accountDetails[0].account.accountHolder.middleName + ' ' + response.data.accountDetails[0].account.accountHolder.lastName) : (response.data.accountDetails[0].account.accountHolder.firstName + ' ' + response.data.accountDetails[0].account.accountHolder.lastName);
                    self.phNo = response.data.accountDetails[0].account.accountHolder.workPhone;
                    self.emailId = response.data.accountDetails[0].account.accountHolder.workEmail;
                    self.showAddWidget(true);
                    self.loaderStatus(false);
                }
            };

            if (params.navigationFromCardHolder) {
                var selectedAccount = util.cardholderDetails;
                if (params.hasOwnProperty('ceid')) {
                    self.ceid = params.ceid;
                } else {
                    self.ceid = util.ceid;
                }

                self.cardholderAddress = selectedAccount.accountHolder.address;
                self.addLine1(self.cardholderAddress.line1);
                self.addLine2(self.cardholderAddress.line2);
                self.city(self.cardholderAddress.city);
                self.postalCode(self.cardholderAddress.postalCode);
                self.stateCode(self.cardholderAddress.stateCode);
                self.cardholderCountry((self.cardholderAddress.country !== undefined) ? self.cardholderAddress.country : 'United States');
                self.cardholderAddress.country = self.cardholderCountry();
                self.tempCurrentStatus = selectedAccount.status;
                self.getStatus(self.tempCurrentStatus);
                self.fullName = (selectedAccount.accountHolder.middleName !== undefined) ? (selectedAccount.accountHolder.firstName + ' ' + selectedAccount.accountHolder.middleName + ' ' + selectedAccount.accountHolder.lastName) : (selectedAccount.accountHolder.firstName + ' ' + selectedAccount.accountHolder.lastName);
                self.phNo = selectedAccount.accountHolder.workPhone;
                self.emailId = selectedAccount.accountHolder.workEmail;
                self.showAddWidget(true);
                self.loaderStatus(false);

            } else {
                self.loaderStatus(true);
                AJAX.getControlCardDetail(self.getCardHolderCeidReq, self.getCardHolderCeidRes);
            }

        };

        /*self.widgetAddress.subscribe(function (newValue) {
            //console.log(newValue);
        });*/

        self.VerifystolenCard = function() {
            var paramsVerify = {};
            paramsVerify.tab = 'tab1';
            paramsVerify.initModule = 'ca-overview';
            if (self.nextScreen() === 'changeName') {
                paramsVerify.newName = self.updatedName();
            }
            paramsVerify.parentObject = self;
            paramsVerify.showButtons = self.showButtons();
            paramsVerify.disableRequest = self.disableRequest();
            paramsVerify.tollFree = self.tollFree;
            paramsVerify.international = self.international;
            paramsVerify.isCancelClicked = self.isCancelClicked();
            paramsVerify.stolenCountry = self.stolenCountry();
            paramsVerify.briefDesc = self.briefDesc();
            paramsVerify.isDispute = self.isDispute;
            paramsVerify.phNo = self.phNo;
            paramsVerify.email = self.emailId;
            paramsVerify.isElite = self.isElite();
            paramsVerify.ceid = self.ceid;
            paramsVerify.showTab = self.showTab();
            paramsVerify.nextScreen = self.nextScreen();
            paramsVerify.showScreen = self.showScreen();
            paramsVerify.showTransTable = self.showTransTable();
            paramsVerify.postTransResponse = self.postTransactionResponse();
            paramsVerify.authResponse = self.authTransactionResponse();
            paramsVerify.totalResponse = self.totalPostTransResponse();
            paramsVerify.cardholderName = self.cardHolderName;
            paramsVerify.accntNumber = self.lastFourDigit.split('.')[4];
            paramsVerify.addressObject = self.cardholderAddress;
            paramsVerify.showState = self.showState;
            paramsVerify.cardLostCountry = self.stolenCountry();
            paramsVerify.expectedDays = self.expectedDays;
            paramsVerify.updatedName = self.updatedName();
            paramsVerify.uploadArray = self.binaryfile();
            paramsVerify.isNewAddress = self.isNewAddress();
            paramsVerify.shippingAddress = (self.isNewAddress()) ? self.widgetAddress() : self.cardholderAddress;
            paramsVerify.isAddressOnRecord = (self.isNewAddress()) ? 'No' : 'Yes';
            paramsVerify.selectDate = self.selectDate();
            paramsVerify.cancelClicked = self.isCancelClicked;

            require(['navigation', 'mockConfig'], function(navigation) {
                var nav = navigation('reportstolencardverify', paramsVerify);
            });
        };
        self.selectedOption.subscribe(function(newValue) {
            if (newValue.value === 'Other') {
                self.stolenCountry('');
                self.othersCountry(true);
            } else {
                self.stolenCountry(newValue.value);
                self.othersCountry(false);
            }
        });

        self.clearData = function() {

            self.briefDesc('');
            self.expectedDays(undefined);
            util.selectedAuth = [];
            util.selectedPost = [];
            self.isVerify(false);
            self.showState(undefined);
            self.stolenCountry(' ');
            self.selectedFraudAuth = [];
            self.selectedFraudPost = [];
            self.binaryfile([]);
            self.fileName([]);
            self.isNewAddress(false);
        };
        self.loadStolenScreen = function() {
            self.clearData();
            self.isCancelClicked(false);
            self.loaderStatus(true);
            self.showButtons(true);
            self.cardHolderText('Cardholder Name');
            self.showTab('tab1');
            self.isVerify(false);
            self.showScreen('report');
            self.nextScreen('validate');
            $('.ca-stolenCard-footer-container').show();
            var $footerContainer = $('.ca-stolenCard-footer-container');
            var $replaceContainer = $('.ca-request-replacementCard-container');
            var $reportCardInfo = $('.report-card-info-container');
            var $requestStolenContainer = $('.whole-content');
            if ($replaceContainer.hasClass('active')) {
                $replaceContainer.removeClass('active');
            }
            $replaceContainer.addClass('inactive');
            $('#tab2').addClass('inactive');
            if ($reportCardInfo.hasClass('active')) {
                $reportCardInfo.removeClass('active');
            }
            $reportCardInfo.addClass('inactive');
            $requestStolenContainer.addClass('active');
            $footerContainer.addClass('active');
            self.authTransactionsReqData = self.authTransReq();
            self.postTransactionsReqData = self.postTransReq();
            if (util.selectedAuth.length === 0 && util.selectedPost.length === 0) {
                self.loaderStatus(true);
                AJAX.getAuthTransData(self.authTransactionsReqData, self.getAuthTransactionsRes);
                AJAX.getPostTransData(self.postTransactionsReqData, self.getPostTransactionsRes);
                self.disableNxtBtn(true);
            } else {
                self.disableNxtBtn(false);
                self.loaderStatus(false);
            }
        };
        self.freezeCardScreen = function() {
            self.showButtons(true);
            self.cardHolderText('Cardholder Name');
            self.showTab('tab1');
            self.showScreen('report');
            self.nextScreen('freeze');
            $('.ca-stolenCard-footer-container').show();
            var $footerContainer = $('.ca-stolenCard-footer-container');
            var $replaceContainer = $('.ca-request-replacementCard-container');
            var $reportCardInfo = $('.report-card-info-container');
            var $requestStolenContainer = $('.whole-content');
            if ($replaceContainer.hasClass('active')) {
                $replaceContainer.removeClass('active');
            }
            $replaceContainer.addClass('inactive');
            $('#tab2').addClass('inactive');
            if ($reportCardInfo.hasClass('active')) {
                $reportCardInfo.removeClass('active');

            }
            $reportCardInfo.addClass('inactive');

            if ($requestStolenContainer.hasClass('inactive')) {
                $requestStolenContainer.addClass('inactive');
            }
            $requestStolenContainer.addClass('active');
            if ($footerContainer.hasClass('inactive')) {
                $footerContainer.removeClass('inactive');
            }
            $footerContainer.addClass('active');
            self.showScreen('freeze');
        };
        self.loadReplacCard = function() {
            self.nextScreen('replace');
            self.isCancelClicked(true);
            self.showTab('tab2');
            self.enableNxtBtn();
            $('.ca-stolenCard-footer-container').show();
            var $footerContainer = $('.ca-stolenCard-footer-container');
            var $reportContainer = $('.ca-report-stolenCard-container');
            var $replaceCardInfo = $('.request-card-info-container');
            var $replaceStolenContent = $('.replacmentCard-whole-content');
            $('#tab1').addClass('inactive');
            $replaceCardInfo.addClass('inactive');
            $reportContainer.addClass('inactive');
            $replaceStolenContent.addClass('active');
            $footerContainer.addClass('active');
        };
        self.loadDamageScreen = function() {
            self.clearData();
            self.isCancelClicked(false);
            self.cardHolderText('Cardholder Name');
            self.loadReplacCard();
            self.showScreen('damage');
            self.isCancelClicked(true);
            self.replaceCardTitle('Replace a damaged card');
            var $cardNeverReceived = $('.card-never-received');
            var $replaceDamageContainer = $('.replace-damage-card');
            var $changeNameContainer = $('.change-name-on-card');
            $replaceDamageContainer.addClass('active');
            self.disableNxtBtn(false);
            $('.ca-stolenCard-footer-container').show();
            self.showButtons(true);
            if ($cardNeverReceived.hasClass('active')) {
                $cardNeverReceived.removeClass('active');
            }
            if ($changeNameContainer.hasClass('active')) {
                $changeNameContainer.removeClass('active');
            }
            self.nextScreen('damage');
        };
        self.cardNeverReceived = function() {
            self.clearData();
            self.cardHolderText('Cardholder Name');
            self.isCancelClicked(false);
            self.loadReplacCard();
            self.isCancelClicked(true);
            self.replaceCardTitle('Report a new card never received');
            var $cardNeverReceived = $('.card-never-received');
            var $replaceDamageContainer = $('.replace-damage-card');
            var $changeNameContainer = $('.change-name-on-card');
            $cardNeverReceived.addClass('active');
            self.showScreen('cardNeverReceived');
            self.nextScreen('verifyCardNeverReceived');
            $('.ca-stolenCard-footer-container').show();
            self.showButtons(true);
            self.disableNxtBtn(true);
            if ($replaceDamageContainer.hasClass('active')) {
                $replaceDamageContainer.removeClass('active');
            }
            if ($changeNameContainer.hasClass('active')) {
                $changeNameContainer.removeClass('active');
            }
            $('.ca-content').css('min-height', '780px');
        };
        self.changeNameOncard = function() {
            self.clearData();
            self.cardHolderText('Current Name on Card');
            self.isCancelClicked(false);
            self.loadReplacCard();
            self.isCancelClicked(true);
            self.replaceCardTitle('Change a name on a card');
            var $changeNameContainer = $('.change-name-on-card');
            var $cardNeverReceived = $('.card-never-received');
            var $replaceDamageContainer = $('.replace-damage-card');
            $changeNameContainer.addClass('active');
            self.nextScreen('changeName');
            self.showScreen('changeName');
            $('.ca-stolenCard-footer-container').show();
            self.showButtons(true);
            self.disableNxtBtn(true);
            $('#upName').val('');
            if ($cardNeverReceived.hasClass('active')) {
                $cardNeverReceived.removeClass('active');
            }
            if ($replaceDamageContainer.hasClass('active')) {
                $replaceDamageContainer.removeClass('active');
            }
            if (document.addEventListener && !window.requestAnimationFrame) { //ie9 detection hack - @rpandidu
                if (!FileAPI.support.flash) {
                    self.showAttachErrorMsg(true);
                }
                $('#fileUpload').parent().parent().addClass('js-fileapi-wrapper');
                $('#fileUpload').parent().addClass('ca-ie-nine');
                ko.cleanNode($('#fileUpload').parent()[0]); //unbind the FileReader as it is not supported in IE9
                var ret = $('input[type="file"]').on('change', function(evt) {
                    self.flashFileUpload("dummy", evt);
                });
            }
        };
        self.enableNxtBtn = function() {
            if (!self.disableResult()) {
                if (self.nextScreen() === 'validate') {
                    if (self.showState() === 'yes') {
                        self.disableNxtBtn(false);
                    } else if (self.showState() === 'no') {
                        if (self.selectedOption()) {
                            if (self.selectedOption().value !== 'Select' && self.selectedOption().value !== 'Other') {
                                self.disableNxtBtn(false);
                            } else if (self.selectedOption().value === 'Other' && self.stolenCountry().trim() !== '') {
                                self.disableNxtBtn(false);
                            } else {
                                self.disableNxtBtn(true);
                            }
                        }
                    }
                } else if (self.nextScreen() === 'verify') {
                    if (self.expectedDays() !== undefined || self.isElite()) {
                        self.disableNxtBtn(false);
                    } else if (util.selectedPost.length > 0 || util.selectedAuth.length > 0) {
                        self.disableNxtBtn(false);
                    } else {
                        self.disableNxtBtn(true);
                    }

                } else if (self.nextScreen() === 'verifyCardNeverReceived') {
                    if (self.selectDate() !== undefined && self.selectDate().trim() !== '') {
                        self.disableNxtBtn(false);
                    } else {
                        self.disableNxtBtn(true);
                    }
                } else if (self.nextScreen() === 'changeName') {
                    if (self.updatedName() !== undefined) {
                        if (self.updatedName().trim() !== '' && self.expectedDays() !== undefined && self.binaryfile().length !== 0) {
                            self.disableNxtBtn(false);
                        } else if (self.isElite()) {
                            if (self.updatedName().trim() !== '' && self.binaryfile().length !== 0) {
                                self.disableNxtBtn(false);
                            } else {
                                self.disableNxtBtn(true);
                            }
                        } else {
                            self.disableNxtBtn(true);
                        }
                    } else {
                        self.disableNxtBtn(true);
                    }

                }
            }
        };
        self.updatedName.subscribe(function(newName) {
            self.enableNxtBtn();
        });
        self.disableResult.subscribe(function(newValue) {
            if (newValue === false) {
                if (self.nextScreen() !== 'damage') {
                    self.enableNxtBtn();
                } else {
                    self.disableNxtBtn(false);
                }
            } else {
                self.disableNxtBtn(true);
            }
        });
        self.selectDate.subscribe(function(newDate) {
            self.enableNxtBtn();
        });
        self.showState.subscribe(function(newValue) {
            self.enableNxtBtn();
            if (newValue === 'no') {
                self.dropdowndefault({
                    id: 1,
                    value: 'Select'
                });
            }
        });
        self.stolenCountry.subscribe(function(newValue) {
            self.enableNxtBtn();
        });
        self.expectedDays.subscribe(function(newValue) {
            self.enableNxtBtn();
        });

        self.getUploadFileRequest = function() {
            if (!self.disableAttachBtn()) {

                var data;
                var tempArray = [];
                ko.utils.arrayForEach(self.fileName(), function(file, index) {
                    data = {
                        fileName: self.fileName()[index].fname
                    };
                    tempArray.push(data);

                });
                self.binaryfile(tempArray);
                return self.binaryfile();
            }
        };
        self.nextBtnClick = function() {
            var $report = $('#reportStolen');
            var $validate = $('#validateActivity');
            var $shipping = $('#shipping');
            if (!self.disableNxtBtn()) {
                if (self.nextScreen() === 'validate') {
                    self.showTransTable(true);
                    $validate.addClass('active');
                    $report.removeClass('active');
                    self.nextScreen('shipping');
                    if (self.postTransactionResponse().length < 0 || self.postTransactionResponse().length < 51) {
                        self.isBorderNone(true);
                    }
                } else if (self.nextScreen() === 'shipping') {
                    self.showTransTable(false);
                    $validate.removeClass('active');
                    $shipping.addClass('active');
                    self.nextScreen('verify');
                    self.isBorderNone(false);
                    if ((util.selectedAuth.length === 0 && util.selectedPost.length === 0) || self.isElite()) {
                        self.showExpedited(true);
                    } else {
                        self.showExpedited(false);
                    }
                    self.showFreeText((util.selectedAuth.length === 0 && util.selectedPost.length === 0)?false:true);
                    self.disableNxtBtn(true);
                    self.enableNxtBtn();
                } else if (self.nextScreen() === 'verify') {
                    self.showTransTable(true);
                    self.VerifystolenCard();
                } else if (self.nextScreen() === 'replace') {
                    self.VerifystolenCard();
                } else if (self.nextScreen() === 'damage') {
                    self.showScreen('verifyDamage');
                    self.nextScreen('VerifyDamage');
                    self.showTransTable(false);
                    self.VerifystolenCard();
                } else if (self.nextScreen() === 'verifyCardNeverReceived') {
                    self.showScreen('verifyCardNeverReceived');
                    self.showTransTable(false);
                    self.VerifystolenCard();
                } else if (self.nextScreen() === 'changeName') {
                    self.showTransTable(false);
                    self.showScreen('changeName');
                    self.VerifystolenCard();
                }
            }
        };
        self.backBtnClick = function() {
            var $report = $('#reportStolen');
            var $validate = $('#validateActivity');
            var $shipping = $('#shipping');
            var $footerContainer = $('.ca-stolenCard-footer-container');
            var $wholeContent = $('.replacmentCard-whole-content');
            var $tabReplace = $('.request-card-info-container');
            var $requestStolenContainer = $('.whole-content');
            var $tab1 = $('#tab1');
            if (self.nextScreen() === 'shipping') {
                self.nextScreen('validate');
                self.showTransTable(false);
                self.isBorderNone(false);
                $validate.removeClass('active');
                $report.addClass('active');
                $requestStolenContainer.addClass('active');

            } else if (self.nextScreen() === 'validate' || self.nextScreen() === 'freeze') {
                self.showTransTable(false);
                self.showButtons(false);
                $('#tab2').removeClass('inactive');
                $requestStolenContainer.removeClass('active');
                var $reportCardInfo = $('.report-card-info-container');
                $shipping.removeClass('active');
                $reportCardInfo.removeClass('inactive');
                $footerContainer.removeClass('active').addClass('inactive');
                //console.log('Back');
            } else if (self.nextScreen() === 'verify') {
                self.nextScreen('shipping');
                self.showTransTable(true);
                self.disableNxtBtn(false);
                $shipping.removeClass('active');
                $validate.addClass('active');
                if (self.postTransactionResponse().length === 0) {
                    self.isBorderNone(true);
                }
            } else if (self.nextScreen() === 'changeName') {
                $wholeContent.removeClass('active');
                $tabReplace.removeClass('inactive');
                $tab1.removeClass('inactive');
                self.showButtons(false);
            } else if (self.nextScreen() === 'verifyCardNeverReceived') {
                $wholeContent.removeClass('active');
                $tabReplace.removeClass('inactive');
                $tab1.removeClass('inactive');
                self.showButtons(false);
                $('.ca-content').css('min-height', '300px');
            } else if (self.nextScreen() === 'damage') {
                $wholeContent.removeClass('active');
                $tabReplace.removeClass('inactive');
                $tab1.removeClass('inactive');
                self.showButtons(false);
            }
        };
        //Freeze card code starts-rrajagop
        self.freezeReq = function() {
            var program = util.selectedEntitledProgram;
            var reqObj = {
                "data": {
                    "type": "FREEZE",
                    "account": [{
                        "id": self.ceid,
                        "status": "F"
                    }],
                    reportLsEmail: {
                        programName: program.programName,
                        cardholderName: self.cardHolderName,
                        lastFourDigit: self.lastFourDigit.split('.')[4]
                    }
                }
            };
            return reqObj;
        };
        self.uploadFile = function() {
            $('#fileUpload').click();
        };
        self.showFreezeSuccess = function() {
            var $backButton = $('.ca-stolenCard-back-button');
            self.showSuccess(true);
            self.showScreen('freezeConfirm');
            $backButton.addClass('inactive');
            self.loaderStatus(false);
        };
        self.freezeRes = function(data) {
            var $backButton = $('.ca-stolenCard-back-button');

            if (data.data && data.data.result && data.data.result.messageCode && data.data.result.messageCode !== '0') {
                self.showFailure(true);
                self.showScreen('freezeConfirm');
                $backButton.addClass('inactive');
                self.loaderStatus(false);
            } else {
                if (params.navigationFromCardHolder) {

                    for (var i = 0; i < util.entitledPrograms.length; i += 1) {
                        if (util.selectedProgram.id === util.entitledPrograms[i].program.companyId) {
                            self.cachedProgram = util.entitledPrograms[i];
                        }
                    }

                    delete self.cachedProgram.program.controlCard;
                    delete self.cachedProgram.program.subAccount;

                    self.showFreezeSuccess();
                } else {
                    util.entitledPrograms[self.entitledProgramIndex].program.subAccount[self.subAccountsIndex].account.status = 'F';
                    self.showFreezeSuccess();
                }
            }
        };

        self.openContactInfo = function() {
            window.open(self.urls.contactServiceUrl);
        };
        self.confirmBtnClicked = function() {
            AJAX.freezeCard(self.freezeReq(), self.freezeRes);
            self.loaderStatus(true);
        };
        self.isCancelClicked.subscribe(function(newValue) {
            if (newValue) {
                var i = 0,
                    length = $('.ca-add-shipping-address-container').length;

                self.dropdowndefault({
                    id: 1,
                    value: 'Select'
                });

                for (i = 0; i < length; i += 1) {
                    ko.cleanNode($('.ca-add-shipping-address-container')[i]);
                    ko.applyBindings(self, $('.ca-add-shipping-address-container')[i]);
                }
                if (self.nextScreen() === 'verifyCardNeverReceived') {
                    ko.cleanNode($('.date-piceker-container')[0]);
                    ko.applyBindings(self, $('.date-piceker-container')[0]);
                } else if (self.nextScreen() === 'changeName') {
                    ko.cleanNode($('.ca-replacementCard-Name-input-container')[0]);
                    ko.applyBindings(self, $('.ca-replacementCard-Name-input-container')[0]);
                }


            } else {
                self.isCancelClicked(true);
            }

        });

        self.saveName = function() {
            self.changeName = self.updatedName();
            self.enableNxtBtn();
        };

        //validations-logic---
        self.allowAlphaNumericSpaceLogic = function(element, event) {
            try {
                var charCode;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === 'object') {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if ((charCode > 64 && charCode < 91) || charCode === 32 || (charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 46) {
                    return true;
                }

                return false;
            } catch (err) {

            }
        };
        self.allowAlphaNumericSpaceApostorphe = function(element, event) {
            try {
                var charCode;
                var selectStart = (event.target !== undefined && event.target !== null) ? event.target.selectionStart : event.srcElement.selectionStart;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === 'object') {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if (selectStart === 0 && charCode === 32) {
                    return false;
                }
                if (charCode === 32) {
                    self.validationSpacecount++;
                } else {
                    self.validationSpacecount = 0;
                }
                if (charCode === 222) {
                    self.validationApostorphecount++;
                } else {
                    self.validationApostorphecount = 0;
                }
                if (((charCode > 64 && charCode < 91) || (charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 32 || charCode === 46 || charCode === 222) && self.validationSpacecount < 2 && self.validationApostorphecount < 2) {
                    return true;
                }

                return false;
            } catch (err) {

            }
        };
        self.allowNumeric = function(element, event) {
            try {
                var charCode;
                if (window.event) {
                    if (self.chromeCtrlEvent(element, event)) {
                        return false;
                    } else if (self.chromeIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = window.event.keyCode;
                } else if (typeof event === 'object') {
                    if (self.firefoxCtrlEvent(element, event)) {
                        return false;
                    } else if (self.firefoxIsShiftkey(element, event)) {
                        return false;
                    }
                    charCode = event.which;
                }
                if ((charCode > 95 && charCode < 106) || (charCode > 46 && charCode < 58) || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 46) {
                    return true;
                }

                return false;
            } catch (err) {

            }

        };
        self.chromeCtrlEvent = function(element, event) {
            return (event.ctrlKey && (event.keyCode === 86 || event.keyCode === 118));
        };
        self.firefoxCtrlEvent = function(element, event) {
            return (event.ctrlKey && (event.which === 86 || event.which === 118));
        };

        self.chromeIsShiftkey = function(element, event) {
            return (event.shiftKey && (event.keyCode > 46 && event.keyCode < 58));
        };
        self.firefoxIsShiftkey = function(element, event) {
            return (event.shiftKey && (event.which > 46 && event.which < 58));
        };

        self.allowAlphaAndSpace = function(element, event) {
            var charCode;
            if (window.event) {
                if (self.chromeCtrlEvent(element, event)) {
                    return false;
                } else if (self.chromeIsShiftkey(element, event)) {
                    return false;
                }
                charCode = window.event.keyCode;
            } else if (typeof event === 'object') {
                if (self.firefoxCtrlEvent(element, event)) {
                    return false;
                } else if (self.firefoxIsShiftkey(element, event)) {
                    return false;
                }
                charCode = event.which;
            }
            if ((charCode > 64 && charCode < 91) || charCode === 32 || charCode === 8 || charCode === 9 || charCode === 37 || charCode === 39 || charCode === 46) {
                return true;
            }

        };
        self.loadTab = function() {
            self.closeModel();

        };

        self.doNothing = function() {

        };
        //validations ends
        self.getAccountDetails();
        self.getCardHolderCeid();
        ko.applyBindings(self, $('.ca-stolencard')[0]);
        $('.svb-cardsAdmin').show();
        if (params.replace !== undefined && params.replace) {
            $('.ca-tabItem2').trigger('click');
        }
        if (params !== undefined && params.enable !== undefined) {
            params.enable(true);
        }
        $('.ca-stolenCard-descr-box').on('keydown', function(event) {
            var text = $(this).val();
            //Get the maxlength
            var limit = $(this).attr('maxlength');
            //Check if the length exceeds what is permitted
            if (text.length >= Number(limit)) {
                //Truncate the text if necessary                
                var charCode = (event.which) ? event.which : event.keyCode;
                if (charCode === 8) {
                    return true;
                } else {
                    return false;
                }
            }

        });
        return self;
    }
    return ReportStolenCard;
});