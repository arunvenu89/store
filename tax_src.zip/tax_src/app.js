var requireCA = requirejs.config({
    "baseUrl": "",
    "waitSeconds": 200,
    "paths": configpath,
    "shim": {
        "placeholder": ["jqMask"],
        "loadingOverlay": ["modernizr"],
        "FileAPIexif": ["FileAPI"],
        "FileAPIid3": ["FileAPI"],
        "reportstolencardModule": [ "FileAPIexif", "FileAPIid3"]
    }
});
var allCa=[], moduleInit;
require.onResourceLoad = function(context, map, depArray){
    allCa.push(map.name);
};
function endCa(){
    allCa.map(function(item){
        require.undef(item);
    });
}
requireCA(["require", "domReady","jqueryNoConflict"], function () {

    require(["navigation", "util", "jquery", "mockConfig", "loadingOverlay"], function (navigation, util, $) {

        //disable double click
        $(document).on("keydown", function (e) {
            if (e.which === 8 && !$(e.target).is("input, textarea")) {
                e.preventDefault();
            }
        });
        $('button').dblclick(function (e) {
            e.preventDefault();
        });

        util.requestedBy = requestedBy;
        util.isProduction = isProduction;
        moduleInit = new navigation(initModule);
    });
});