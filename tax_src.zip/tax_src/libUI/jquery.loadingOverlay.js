/**
 * Waiting jQuery Plugin.
 *
 * Arguments:
 *  options
 *
 */
!function(factory) {
    "function" == typeof define && define.amd ? define(["jquery", "modernizr"], factory) : factory("object" == typeof exports ? require("jquery") : jQuery);
}(function ($, Modernizr) {

    var methods = {
        start: function() {

            var $indicator = $(this),
                dot       = '<div class="svb-processing-indicator-dot"></div>',
                delay     = 200;


            String.prototype.repeat = function(num) {
                return new Array(num + 1).join(this);
            };

            $indicator.append( dot.repeat(5) );

            var $dot = $('.svb-processing-indicator-dot'),
                lastDot = $dot.length - 1;

            function jqueryAnimate() {

                $dot.each(function(i){

                    var $this = $(this),
                        delay = 250 * i,
                        speed = 500;

                    $this.delay(delay).animate({opacity: '1'}, speed, function() {
                        $this.animate({opacity: '0'}, function(){
                            if( i === lastDot ){
                                jqueryAnimate();
                            }
                        });
                    });

                });
            }

            if(Modernizr && Modernizr.cssanimations ) {
                $('.svb-ca-loading-overlay').addClass("overlay-active");
                 $indicator.addClass('svb-ca-inprocess-indicator');


            } else {

                jqueryAnimate();

            }
        },
        stop: function(){
            var $indicator = $(this);
            $('.svb-ca-loading-overlay').removeClass("overlay-active");
            $indicator.removeClass('svb-ca-inprocess-indicator');
            $indicator.html("");


        }
    };

    $.fn.processingIndicator = function(method) {
        // Method calling logic
        if (methods[method]) {
            return methods[ method ].apply(this, arguments);
        }
        else {
            $.error('Method ' + method + ' does not exist on jQuery.svb.processingIndicator');
        }
    };

});
