define(['jquery', "mockjax"], function ($) {

    var readJSON = function (file) {
        var request = new XMLHttpRequest();
        request.open('GET', file, false);
        request.send(null);
        if (request.status == 200)
            return request.responseText;
    };

    $.mockjax({
        url: '/getDonutData',
        response: function (settings) {
            this.responseText = readJSON('Mock/donutData.json');
        }
    });

    $.mockjax({
        url: '/getNotification',
        response: function (settings) {
            this.responseText = readJSON('Mock/getNotification.json');
        }
    });

    $.mockjax({
        url: '/getCompanyViewAccount',
        response: function (settings) {
            this.responseText = readJSON('Mock/table.json');
        }
    });

    $.mockjax({
        url: '/getCompanyViewAccount1',
        response: function (settings) {
            this.responseText = readJSON('Mock/table1.json');
        }
    });

    $.mockjax({
        url: '/getControlAccount',
        response: function (settings) {
            this.responseText = readJSON('Mock/controlAccount.json');
        }
    });

    $.mockjax({
        url: '/getFlags',
        response: function (settings) {
            this.responseText = readJSON('Mock/getFlags.json');
        }
    });

    $.mockjax({
        url: '/getControlCardData',
        response: function (settings) {
            this.responseText = readJSON('Mock/controlCardDetails.json');
        }
    });

    $.mockjax({
        url: '/getAuthTransactions',
        response: function (settings) {
            this.responseText = readJSON('Mock/authTransactionsData.json');
        }
    });

    $.mockjax({
        url: '/getPostTransactions',
        response: function (settings) {
            this.responseText = readJSON('Mock/postTransactionsData.json');
        }
    });

    $.mockjax({
        url: '/getStatementDates',
        response: function (settings) {
            this.responseText = readJSON('Mock/statementDates.json');
        }
    });

    $.mockjax({
        url: '/getPaymentAccounts',
        response: function (settings) {
            this.responseText = readJSON('Mock/getPaymentAccounts.json');
        }
    });

    $.mockjax({
        url: '/initPayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/initPayment.json');
        }
    });

    $.mockjax({
        url: '/getSearchBankRoutingDetails',
        response: function (settings) {
            this.responseText = readJSON('Mock/getSearchBankRoutingDetails.json');
        }
    });

    $.mockjax({
        url: '/getStatementsList',
        response: function (settings) {
            this.responseText = readJSON('Mock/getStatementsList.json');
        }
    });

    $.mockjax({
        url: '/reviewPayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/reviewPayment.json');
        }
    });

    $.mockjax({
        url: '/makePayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/makePayment.json');
        }
    });

    $.mockjax({
        url: '/updatePayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/makePayment.json');
        }
    });


    $.mockjax({
        url: '/addPaymentAccountService',
        response: function (settings) {
            this.responseText = readJSON('Mock/addPaymentAccountService.json');
        }
    });
    
    $.mockjax({
        url: '/getPendingApprovalPayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/getPendingApprovalPayment.json');
        }
    });

    $.mockjax({
        url: '/getChangeStatusResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/getChangeStatusResponse.json');
        }
    });

    $.mockjax({
        url: '/getSpendLimitResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/getSpendLimitResponse.json');
        }
    });

    $.mockjax({
        url: '/getCashAdvanceResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/getCashAdvanceResponse.json');
        }
    });

    $.mockjax({
        url: '/checkPayAccUsed',
        response: function (settings) {
            this.responseText = readJSON('Mock/checkPayAccUsed.json');
        }
    });

    $.mockjax({
        url: '/deletePaymentAccount',
        response: function (settings) {
            this.responseText = readJSON('Mock/deletePaymentAccount.json');
        }
    });

    $.mockjax({
        url: '/scheduledPayments',
        response: function (settings) {
            this.responseText = readJSON('Mock/scheduledPayments.json');
        }
    });

    $.mockjax({
        url: '/paymentHistory',
        response: function (settings) {
            this.responseText = readJSON('Mock/paymentHistory.json');
        }
    });

    $.mockjax({
        url: '/deletePayment',
        response: function (settings) {
            this.responseText = readJSON('Mock/deletePayment.json');
        }
    });
    
    $.mockjax({
        url: '/newCardRegristration',
        response: function (settings) {
            this.responseText = readJSON('Mock/newCardRegristration.json');
        }
    });
    
    $.mockjax({
        url: '/permanantIncreaseReq',
        response: function (settings) {
            this.responseText = readJSON('Mock/permanentIncreaseRes.json');
        }
    });
    
    $.mockjax({
        url: '/getPendingMaintenanceRequest',
        response: function (settings) {
            this.responseText = readJSON('Mock/getPendingMaintenanceRequest.json');
        }
    });
    $.mockjax({
        url: '/updateEditCardResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/updateEditCardResponse.json');
        }
    });
    
    $.mockjax({
        url: '/workflowManageSpendEditResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/workflowManageSpendEditResponse.json');
        }
    });
    
    $.mockjax({
        url: '/getPendingApproval',
        response: function (settings) {
            this.responseText = readJSON('Mock/pendingApproval.json');
        }
    });
    $.mockjax({
        url: '/getReviewPendingApproval',
        response: function (settings) {
            this.responseText = readJSON('Mock/reviewPendingApproval.json');
        }
    });
    
    $.mockjax({
        url: '/confirmPendingApproval',
        response: function (settings) {
            this.responseText = readJSON('Mock/confirmPendingApproval.json');
        }
    });
    
    $.mockjax({
        url: '/workflowCashAdvanceEditResponse',
        response: function (settings) {
            this.responseText = readJSON('Mock/workflowCashAdvanceEditResponse.json');
        }
    });
    
    $.mockjax({
        url: '/workflowCashAdvanceEditResponseSingleCard',
        response: function (settings) {
            this.responseText = readJSON('Mock/workflowCashAdvanceEditResponseSingleCard.json');
        }
    });
    
    $.mockjax({
        url: '/workflowManageSpendEditResponseSingleCard',
        response: function (settings) {
            this.responseText = readJSON('Mock/workflowManageSpendEditResponseSingleCard.json');
        }
    });
    
    $.mockjax({
        url: '/cancelCardRequest',
        response: function (settings) {
            this.responseText = readJSON('Mock/cancelCardRequest.json');
        }
    });
    
    $.mockjax({
        url: '/freezeCard',
        response: function (settings) {
            this.responseText = readJSON('Mock/freezeCard.json');
        }
    });
    
    $.mockjax({
		url: '/disputeEmailSend',
        response: function (settings) {
            this.responseText = readJSON('Mock/disputeEmailSend.json');
        }
    });
    
    $.mockjax({
        url: '/overrideNewStatusRequest',
        response: function (settings) {
            this.responseText = readJSON('Mock/overrideNewStatusRequest.json');
        }
    });
    
    $.mockjax({
        url: '/initManageSpend',
        response: function (settings) {
            this.responseText = readJSON('Mock/getInitManageSpend.json');
        }
    });
    
    $.mockjax({
        url: '/initManageSpend',
        response: function (settings) {
            this.responseText = readJSON('Mock/getInitManageSpend.json');
        }
    });
    
    $.mockjax({
        url: '/getPerformAuditReport',
        response: function (settings) {
            this.responseText = readJSON('Mock/performAudit.json');
        }
    });
});