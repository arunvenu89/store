/* jshint browser: true */
define("index",["knockout", "jquery", "ajaxCall", "util", "file-bindings", "widgetRegistry"], function (ko, $, AJAX, util, file) {
    var IncomeTax = function () {
        var self = this;
        
        self.binaryFile = ko.observableArray([]);
        self.fileName = ko.observableArray();
        
        
        var images = ["press_image.jpg", "property-tax-payment.jpg", "tax_paid.jpg", "e-tax.jpg"];
            $(function () {
                var i = 0;
                $("#dvImage").css("background-image", "url(resources/images/" + images[i] + ")");
                setInterval(function () {
                    i++;
                    if (i == images.length) {
                        i = 0;
                    }
                    $("#dvImage").hide();
                        $("#dvImage").css("background-image", "url(resources/images/" + images[i] + ")");
                        $("#dvImage").show();

                }, 5000);
            });
        self.showImage = ko.observable(true);
        
        self.fileData = ko.observable({
                file: ko.observable() // will be filled with a File object		
            });
        self.fileData().file.subscribe(function(val) {            
            self.binaryFile.push(val);
            self.fileName.push(val.name);
            
        });
        
        self.removeUploadedFile = function(index){
            console.log(index());
            var file = self.binaryFile();
            file.splice(index(),1);
            self.binaryFile(file);
        };
        
        self.loadIncomeTax = function(){ 
            self.showImage(false);
        };
        
        self.uploadFile = function() {
            $('#fileUpload').click();
        };

        self.closeTab = function(){
            $('.income_tax_content').remove();
            self.showImage(true);
        };


        };
    ko.applyBindings(new IncomeTax, $('.whole_content')[0]);
    });
    

