/* global document */
define(["knockout", "jquery", "html!incomeTaxTpl", "util", "css!incomeTaxStyle"], function (ko, $, incomeTaxView, util) {
    function incomeTax (params) {
        var self = this;

        self.verbiage = util.verbiage;

        self.optionChosen = ko.observable();
        self.optionsList = ko.observableArray([]);
        self.defaultOption = ko.observable();
        self.listOptionsLength = ko.observable();

        self.itemType = '';
        self.sameItemClicked = false;

        if (typeof params.customColors !== "undefined") {
            self.dropdownColor = params.customColors;
        }

        if (self.optionsList().length === 0) {
            self.optionsList(params.customOptions());
        }

        self.listOptionsLength(self.optionsList().length);

        self.defaultOptionSet = ko.observable(false);

        self.showGeneralIcon = ko.observable(params.showIcon);

        if (self.optionsList().length > 0) {
            if (typeof params.defaultOption === "function") {
                if (params.defaultOption()) {
                    self.defaultOptionSet(true);
                    self.defaultOption(self.optionsList()[params.defaultOption()]);

                    if (params.defaultOption() > 0) {
                        self.showGeneralIcon(false);
                    }
                } else {
                    self.defaultOption(self.optionsList()[0]);
                }
            } else {
                if (params.defaultOption) {
                    self.defaultOptionSet(true);
                    self.defaultOption(self.optionsList()[params.defaultOption]);

                    if (params.defaultOption > 0) {
                        self.showGeneralIcon(false);
                    }
                } else {
                    self.defaultOption(self.optionsList()[0]);
                }
            }

            self.optionChosen(self.defaultOption());
        } else {
            self.defaultOption({
                value: '',
                id: ''
            });
        }

        self.computeOptionChosen = ko.computed(function () {
            params.selectFunction(self.optionChosen());
        });

        params.customOptions.subscribe(function (dataOptions) {
            if (dataOptions.length > 0) {
                self.optionsList(dataOptions);
                self.listOptionsLength(self.optionsList().length);

                if (typeof params.defaultOption === "function") {
                    if (params.defaultOption()) {
                        self.defaultOptionSet(true);
                        self.defaultOption(self.optionsList()[params.defaultOption()]);
                    } else {
                        self.defaultOption(self.optionsList()[0]);
                    }
                } else {
                    if (params.defaultOption) {
                        self.defaultOptionSet(true);
                        //    self.defaultOption = ko.observable(params.defaultOption());
                        self.defaultOption(self.optionsList()[params.defaultOption]);
                    } else {
                        self.defaultOption(self.optionsList()[0]);
                    }
                }

                params.selectFunction(self.defaultOption());
            }
        });

        self.showCardHoldersList = function (element, event) {
            event.stopPropagation();

            var itemType = '.' + $(event.currentTarget).attr('cardtype');

            /*
            if (self.itemType !== '') {
                $('.dropdown').find(self.itemType).addClass('hide-list-item');
            }

            if (self.itemType === itemType) {
                self.sameItemClicked = !self.sameItemClicked;
            } else {
                self.sameItemClicked = false;
            }

            if ((self.itemType !== itemType) || ((self.itemType === itemType) && !self.sameItemClicked)) {
                $('.dropdown').find(itemType).removeClass('hide-list-item');
            }

            self.itemType = itemType;
            */

            if ($('.dropdown').find(itemType).hasClass('hide-list-item')) {
                $(event.currentTarget).find('.ca-header-down-arrow').removeClass('ca-header-up-arrow');
                $('.dropdown').find(itemType).removeClass('hide-list-item');
            } else {
                $(event.currentTarget).find('.ca-header-down-arrow').addClass('ca-header-up-arrow');
                $('.dropdown').find(itemType).addClass('hide-list-item');
            }
        };

        self.optionClicked = function (m, e) {
            e.stopPropagation();

            var element = $(e.target),
                wrapperElement = element.parent().parent().parent().find('.wrapper-dropdown');

            if (wrapperElement.length === 0) {
                element = $(element).parent();
                wrapperElement = element.parent().parent().parent().find('.wrapper-dropdown');
            }
            
            for (var index = 0; index < self.optionsList().length; index += 1) {
                if (String(self.optionsList()[index].id) === String(element.attr('optionid'))) {
                    if (index > 0) {
                        self.showGeneralIcon(false);
                    } else {
                        self.showGeneralIcon(true);
                    }
                    
                    self.defaultOption(self.optionsList()[index]);
                    self.optionChosen(self.optionsList()[index]);
                }
            }

            if (wrapperElement.hasClass('active')) {
                wrapperElement.removeClass('active');
            }
        };

        // toggle down
        self.openDropdown = function (element, event) {
            event.stopPropagation();

            var $target = $(event.target).parent().parent().find('.wrapper-dropdown');

            if ($target.length === 0) {
                $target = $(event.target).parent().parent().parent().parent().find('.wrapper-dropdown');
            }

            if ($target.hasClass('active')) {
                $target.removeClass('active');
            } else {
                $target.addClass('active');
            }

            return true;
        };
        
        $(document).click(function (event) {
            $('.wrapper-dropdown').removeClass('active');
        });

        return self;
    }

    return {
        viewModel: activityDropDown,
        template: activityDropDownView
    };
});