define(["knockout"], function (ko) {
    ko.components.register('incomeTax-widget', {
        require: "incomeTax"
    });
    
    
});
