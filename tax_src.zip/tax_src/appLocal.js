requirejs.config({
    "baseUrl": "",
    "waitSeconds": 200,
    "paths": {
        "jquery": "libUI/jquery-1.11.3.min",
        "knockout": "libUI/knockout-3.3.0",
        "html": "libUI/text",
        "css": "libUI/css",
        "domReady": "libUI/domReady",
        "placeholder":"libUI/jquery.placeholder.min",
        "mockjax": "libUI/mockjax",
        "datePicker": "libUI/jquery.svb-datepicker",
        "jqueryUI": "libUI/jquery-ui",
        "underscore": "libUI/underscore",
        "modernizr":"libUI/modernizr",
        "inputMask": "libUI/jquery.inputmask",
        "FileAPIexif":"libUI/FileAPI.exif",
       // "FileAPIid3":"libUI/FileAPI.id3",
        "FileAPI":"libUI/FileAPI.min",
        
        "mockConfig":"Mock/mockconfig",
        "loadingOverlay":"libUI/jquery.loadingOverlay",
        "file-bindings": "libUI/knockout-file-bindings",
        "navigation":"app/Navigation/navigation",
        "ajaxCall":"app/Common/ajax",
        "util":"app/Common/util",
        "common":"app/Common/common",
        "widgetRegistry":"widgets/widgetRegistry",
        "caStyles":"resources/css/cardsAdmin",
        "overviewModule":"app/Overview/overview",
        "overviewTpl":"app/Overview/overview.html",       
        "dropdownWidget":"widgets/dropdown/dropdown",
        "dropdownWidgetTpl":"widgets/dropdown/dropdown.html",        
        "loaderWidgetTpl":"widgets/loadingOverlay/loadingOverlay.html",
        "index":"index"
        
        /*"incomeTaxTpl":"app/IncomeTax/incomeTax.html",
        "incomeTax":"app/IncomeTax/incomeTax",
*/    },
    "shim": {
          "mockjax": ['jquery'],
          "datePicker": ['jquery', 'jqueryUI'],
          "placeholder":['jquery'],
          "loadingOverlay":['jquery', 'modernizr']
         // "util":['FileAPI','FileAPIid3','FileAPIexif']

     }
});
 /*require(["domReady"], function() {

     require(["navigation", "mockConfig"], function (navigation) {
         navigation(initModule);
     });
});*/
requirejs(["index"]);